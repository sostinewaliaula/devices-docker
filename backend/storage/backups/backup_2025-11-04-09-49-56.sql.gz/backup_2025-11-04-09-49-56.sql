/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: asset_maintenance
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `asset_maintenance` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `asset_id` char(36) NOT NULL,
  `maintenance_type` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `performed_by` char(36) DEFAULT NULL,
  `performed_date` date NOT NULL,
  `cost` decimal(10, 2) DEFAULT NULL,
  `next_maintenance_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  KEY `performed_by` (`performed_by`),
  CONSTRAINT `asset_maintenance_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asset_maintenance_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: asset_request_comments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `asset_request_comments` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `asset_request_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `parent_comment_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `asset_request_id` (`asset_request_id`),
  KEY `user_id` (`user_id`),
  KEY `parent_comment_id` (`parent_comment_id`),
  CONSTRAINT `asset_request_comments_ibfk_1` FOREIGN KEY (`asset_request_id`) REFERENCES `asset_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asset_request_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asset_request_comments_ibfk_3` FOREIGN KEY (`parent_comment_id`) REFERENCES `asset_request_comments` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: asset_requests
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `asset_requests` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `asset_name` varchar(255) NOT NULL,
  `asset_type` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `reason` text NOT NULL,
  `priority` enum('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
  `status` enum('pending', 'approved', 'rejected', 'fulfilled') DEFAULT 'pending',
  `requested_date` date NOT NULL,
  `approved_date` date DEFAULT NULL,
  `approved_by` char(36) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `asset_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asset_requests_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: assets
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `assets` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_price` decimal(10, 2) DEFAULT NULL,
  `current_value` decimal(10, 2) DEFAULT NULL,
  `status` enum('active', 'inactive', 'maintenance', 'retired') DEFAULT 'active',
  `asset_condition` enum('excellent', 'good', 'fair', 'poor') DEFAULT 'good',
  `location` varchar(255) DEFAULT NULL,
  `assigned_to` char(36) DEFAULT NULL,
  `department_id` char(36) DEFAULT NULL,
  `warranty_expiry` date DEFAULT NULL,
  `last_maintenance` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `serial_number` (`serial_number`),
  KEY `assigned_to` (`assigned_to`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `assets_ibfk_1` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL,
  CONSTRAINT `assets_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE
  SET
  NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: backups
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `backups` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `backup_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`backup_data`)),
  `created_by` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `backups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: departments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `departments` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `user_count` int(11) DEFAULT 0,
  `asset_count` int(11) DEFAULT 0,
  `asset_value` varchar(50) DEFAULT '$0',
  `manager` varchar(255) DEFAULT NULL,
  `manager_id` char(36) DEFAULT NULL,
  `parent_id` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: email_templates
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `name` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`variables`)),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: issue_comments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `issue_comments` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `issue_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `issue_id` (`issue_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `issue_comments_ibfk_1` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: issues
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `issues` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum(
  'open',
  'in_progress',
  'resolved',
  'closed',
  'scheduled'
  ) DEFAULT 'open',
  `priority` enum('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  `category` varchar(100) DEFAULT NULL,
  `reported_by` char(36) NOT NULL,
  `assigned_to` char(36) DEFAULT NULL,
  `asset_id` char(36) DEFAULT NULL,
  `department_id` char(36) DEFAULT NULL,
  `estimated_resolution_date` date DEFAULT NULL,
  `actual_resolution_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `reported_by` (`reported_by`),
  KEY `assigned_to` (`assigned_to`),
  KEY `asset_id` (`asset_id`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `issues_ibfk_1` FOREIGN KEY (`reported_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issues_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE
  SET
  NULL,
  CONSTRAINT `issues_ibfk_3` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE
  SET
  NULL,
  CONSTRAINT `issues_ibfk_4` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE
  SET
  NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: mfa_policies
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `mfa_policies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT 1,
  `enforcement_level` enum('optional', 'recommended', 'required') DEFAULT 'optional',
  `target_roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`target_roles`)),
  `exempt_roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`exempt_roles`)),
  `grace_period_days` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` varchar(255) NOT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mfa_policies_enabled` (`enabled`),
  KEY `idx_mfa_policies_enforcement` (`enforcement_level`)
) ENGINE = InnoDB AUTO_INCREMENT = 6 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: mfa_policy_violations
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `mfa_policy_violations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `policy_id` int(11) NOT NULL,
  `violation_type` enum(
  'login_without_mfa',
  'grace_period_expired',
  'policy_violation'
  ) NOT NULL,
  `violation_date` timestamp NULL DEFAULT current_timestamp(),
  `resolved` tinyint(1) DEFAULT 0,
  `resolved_date` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_violation_user` (`user_id`),
  KEY `fk_violation_policy` (`policy_id`),
  CONSTRAINT `fk_violation_policy` FOREIGN KEY (`policy_id`) REFERENCES `mfa_policies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_violation_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 22 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: notifications
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `notifications` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('success', 'error', 'warning', 'info') NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: password_reset_tokens
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `user_id` char(36) NOT NULL,
  `token` varchar(255) NOT NULL,
  `code` varchar(6) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_reset_tokens_user` (`user_id`),
  KEY `idx_reset_tokens_token` (`token`),
  KEY `idx_reset_tokens_expires` (`expires_at`),
  KEY `idx_reset_tokens_used` (`used`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_mfa_compliance
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_mfa_compliance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `policy_id` int(11) NOT NULL,
  `is_compliant` tinyint(1) DEFAULT 0,
  `compliance_date` timestamp NULL DEFAULT NULL,
  `grace_period_end` timestamp NULL DEFAULT NULL,
  `last_reminder_sent` timestamp NULL DEFAULT NULL,
  `reminder_count` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_policy` (`user_id`, `policy_id`),
  KEY `fk_compliance_policy` (`policy_id`),
  CONSTRAINT `fk_compliance_policy` FOREIGN KEY (`policy_id`) REFERENCES `mfa_policies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_compliance_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 22 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_mfa_factors
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_mfa_factors` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `user_id` varchar(36) NOT NULL,
  `factor_id` varchar(255) NOT NULL,
  `factor_type` enum('totp', 'webauthn') NOT NULL DEFAULT 'totp',
  `friendly_name` varchar(255) NOT NULL,
  `secret` text NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_factor` (`user_id`, `factor_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_factor_type` (`factor_type`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `fk_mfa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: user_recovery_codes
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user_recovery_codes` (
  `id` varchar(36) NOT NULL DEFAULT uuid(),
  `user_id` varchar(36) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `is_used` tinyint(1) DEFAULT 0,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_code_hash` (`code_hash`),
  KEY `idx_is_used` (`is_used`),
  CONSTRAINT `fk_recovery_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: users
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` char(36) NOT NULL DEFAULT uuid(),
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` enum('admin', 'manager', 'user') NOT NULL DEFAULT 'user',
  `department_id` char(36) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `email_notifications` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `in_app_notifications` tinyint(1) DEFAULT 1,
  `mfa_enabled` tinyint(1) DEFAULT 0,
  `mfa_enrolled_at` timestamp NULL DEFAULT NULL,
  `last_mfa_verification` timestamp NULL DEFAULT NULL,
  `mfa_policy_required` tinyint(1) DEFAULT 0,
  `mfa_grace_period_end` timestamp NULL DEFAULT NULL,
  `mfa_policy_violations` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `department_id` (`department_id`),
  KEY `idx_users_mfa_enabled` (`mfa_enabled`),
  KEY `idx_users_mfa_enrolled` (`mfa_enrolled_at`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE
  SET
  NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_uca1400_ai_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: asset_maintenance
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: asset_request_comments
# ------------------------------------------------------------

INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '18a28152-ab18-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'followup comment test',
    NULL,
    '2025-10-17 08:09:48',
    '2025-10-17 08:09:48'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '1d3e924e-ab1c-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'comment',
    NULL,
    '2025-10-17 08:38:34',
    '2025-10-17 08:38:34'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '20b43a9d-ab1c-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'comment',
    NULL,
    '2025-10-17 08:38:40',
    '2025-10-17 08:38:40'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '3a9290b5-ab18-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'followup comment test',
    NULL,
    '2025-10-17 08:10:45',
    '2025-10-17 08:10:45'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '5dfe436b-ab1f-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'admin-user-id',
    'IT-Team',
    'tedt',
    NULL,
    '2025-10-17 09:01:51',
    '2025-10-17 09:01:51'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '748e09a7-af36-11f0-97d8-08f1ea8e398e',
    '4bfbbb63-af36-11f0-97d8-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'This is just a followup on the request for a new assets that i had raised',
    NULL,
    '2025-10-22 04:01:25',
    '2025-10-22 04:01:25'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '8f5129eb-ab1e-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'tests email',
    NULL,
    '2025-10-17 08:56:05',
    '2025-10-17 08:56:05'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'b78c413b-ab1e-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'admin-user-id',
    'IT-Team',
    'followup',
    'e411fff3-ab16-11f0-bb86-00155d38011d',
    '2025-10-17 08:57:12',
    '2025-10-17 08:57:12'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'd1c9989a-ab1e-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'admin-user-id',
    'IT-Team',
    'admin comment',
    NULL,
    '2025-10-17 08:57:56',
    '2025-10-17 08:57:56'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'de956654-ab1d-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'tetsts',
    NULL,
    '2025-10-17 08:51:08',
    '2025-10-17 08:51:08'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'e411fff3-ab16-11f0-bb86-00155d38011d',
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'test comments',
    NULL,
    '2025-10-17 08:01:11',
    '2025-10-17 08:01:25'
  );
INSERT INTO
  `asset_request_comments` (
    `id`,
    `asset_request_id`,
    `user_id`,
    `user_name`,
    `comment`,
    `parent_comment_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'f2f96bb5-ab98-11f0-a366-00155d38011d',
    'de8f8ed9-ab95-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'follow up comment',
    NULL,
    '2025-10-17 13:36:24',
    '2025-10-17 13:36:24'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: asset_requests
# ------------------------------------------------------------

INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '1697564a-a77e-11f0-b195-08f1ea8e398e',
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    'Request for Laptop',
    'Laptop',
    'Electronics',
    'My laptop has a broken screen.',
    'high',
    'pending',
    '2025-10-12',
    NULL,
    NULL,
    NULL,
    '2025-10-12 08:14:02',
    '2025-10-12 08:14:02'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '4bfbbb63-af36-11f0-97d8-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Request for Laptop',
    'Laptop',
    'Electronics',
    'I need a new Laptop as my current one has some issue that is affecteing my productivity in my work.',
    'medium',
    'pending',
    '2025-10-22',
    NULL,
    NULL,
    NULL,
    '2025-10-22 04:00:17',
    '2025-10-22 04:00:17'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '6397d9d0-a4e1-11f0-a26e-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Request for Laptop',
    'Laptop',
    'Electronics',
    'i need a laptp - test',
    'medium',
    'pending',
    '2025-10-09',
    NULL,
    NULL,
    'almost there',
    '2025-10-09 00:27:18',
    '2025-10-17 06:26:19'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'b11c4c17-0f58-42a6-83e9-041112f2dc71',
    '0701ffe5-a51f-11f0-a26e-08f1ea8e398e',
    'RAM',
    'Other',
    'Personal',
    'Engineering work often involves running multiple resource which consumes more resources, this is needed to improve machine performance.',
    'urgent',
    'pending',
    '2025-10-31',
    NULL,
    NULL,
    'The engineer needs additional 8Gb RAM to boost what is currently there.',
    '2025-10-31 00:08:37',
    '2025-10-31 00:17:03'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'b55cb27b-ab9a-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Request for Desktop',
    'Monitor',
    'Electronics',
    'https://github.com/Embarcadero/Dev-Cpp/releases/download/v6.3/Embarcadero_Dev-Cpp_6.3_TDM-GCC_9.2_Setup.exe',
    'medium',
    'pending',
    '2025-10-17',
    NULL,
    NULL,
    'test follow up resquest',
    '2025-10-17 13:49:00',
    '2025-10-18 09:43:07'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'd2af2d39-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Request for Laptop',
    'Laptop',
    'Electronics',
    'this is just a test request for my mail',
    'medium',
    'pending',
    '2025-10-17',
    NULL,
    NULL,
    NULL,
    '2025-10-17 07:03:26',
    '2025-10-17 12:49:22'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'de8f8ed9-ab95-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Request for Monitor',
    'Monitor',
    'Electronics',
    'this is a test asset request',
    'medium',
    'pending',
    '2025-10-17',
    NULL,
    NULL,
    NULL,
    '2025-10-17 13:14:22',
    '2025-10-17 13:14:22'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'ea8849b6-a8f0-11f0-b195-08f1ea8e398e',
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    'Request for Laptop',
    'Laptop',
    'Electronics',
    'My current device has a broken screen that significantly hinders my ability to perform daily tasks effectively. Being part of the engineering team, having a functional laptop is essential for my work. I would be grateful if this request could be prioritized to minimize disruption to ongoing projects. Please let me know if any additional documentation or approvals are required to facilitate the process. Thank you for your attention and support.',
    'high',
    'pending',
    '2025-10-14',
    NULL,
    NULL,
    NULL,
    '2025-10-14 04:28:30',
    '2025-10-14 04:28:30'
  );
INSERT INTO
  `asset_requests` (
    `id`,
    `user_id`,
    `asset_name`,
    `asset_type`,
    `category`,
    `reason`,
    `priority`,
    `status`,
    `requested_date`,
    `approved_date`,
    `approved_by`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'fd292d4c-ab28-11f0-8d03-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    'Request for Other',
    'Other',
    'Electronics',
    'My laptop battery is faulty and no longer retain charge as expected so i must keep the laptop constantly connected to power source. Any brief power outage that last for more than 25 minutes  affects my work. I kindly request a replacement batter (or a long lasting battery)\n\nLaptop model:\n  - System Model: HP EliteBook 840 G3\n  - BIOS: N75 Ver. 01.55 (type: UEFI)\n  - Processor: Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz (4 CPUs), ~2.6GHz',
    'medium',
    'pending',
    '2025-10-17',
    NULL,
    NULL,
    NULL,
    '2025-10-17 00:14:57',
    '2025-10-17 03:06:33'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: assets
# ------------------------------------------------------------

INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '1ce0a0be-fc60-4446-9a9f-5ecded5967d7',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG6280C58',
    '2024-07-15',
    0.00,
    359999.99,
    'active',
    'excellent',
    'Remote',
    NULL,
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    NULL,
    '8GB RAM,\n512GB ssd,\nCorei7',
    '2025-09-09 00:18:04',
    '2025-10-19 08:59:00'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '291f4ab9-dae9-4365-a5f3-5ae507254c69',
    'HP EliteBook',
    'Laptop',
    'Electronics',
    'Dell',
    '840 G3',
    '5CG7121632',
    '2025-10-27',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    'a73544e3-a51d-11f0-a26e-08f1ea8e398e',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    NULL,
    NULL,
    'Intel Core i7 2.6GHz\n16GB RAM 238GB SSD',
    '2025-10-27 05:29:25',
    '2025-10-27 05:29:25'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '2d96139e-c563-4025-b69d-15a2bab3c8dd',
    'HP ElliteBook',
    'Laptop',
    'Electronics',
    'HP',
    '840 G3',
    '5CG718061B',
    '2025-09-21',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    'b6d63cfa-f2d1-4e55-85f2-57d76e8a46a0',
    '249993e1-7e0d-4d1d-8e92-cad9ca730a37',
    NULL,
    NULL,
    '32GB RAM,\nCore i7',
    '2025-09-22 02:51:52',
    '2025-10-29 00:32:29'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '2da0fd4b-2354-450f-a727-7d4fd80706cd',
    'Lenovo Core i3',
    'Laptop',
    'Office Equipment',
    'Lenovo',
    NULL,
    'PF07RSZW',
    '2022-09-15',
    46980.00,
    46980.00,
    'active',
    'excellent',
    'Headquarters - Floor 1',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    NULL,
    '2025-09-08 23:36:00',
    '2025-10-29 00:06:34'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '38a0ae46-ad91-483e-9fe2-4b6c992bc730',
    'HP ELITEBook ',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG7340GPV',
    '2024-02-26',
    0.00,
    0.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '8GB RAM,\n512GB ssd,\nCorei7',
    '2025-09-09 00:10:38',
    '2025-09-09 00:13:12'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '42593bd9-2a2a-4d27-86ef-230965e66a5e',
    'HP EliteBook',
    'Laptop',
    'Electronics',
    'Dell',
    '840 G4',
    '5CG8210WWY',
    '2025-10-27',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '6286cdc4-a51e-11f0-a26e-08f1ea8e398e',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    NULL,
    NULL,
    'Intel Core i7 2.8GHz\n16 GB RAM',
    '2025-10-27 05:36:18',
    '2025-10-27 05:36:18'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '427c8cd7-140d-4e6c-af3f-0a02b7c022d1',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840 G3',
    '5CG9112QW6',
    '2024-02-01',
    0.00,
    0.00,
    'active',
    'excellent',
    'Remote',
    '08ab7a9c-a523-11f0-a26e-08f1ea8e398e',
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-09 00:06:33',
    '2025-10-27 05:33:04'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '48206556-0d81-4b27-919b-1994c6af2a9f',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG8340HC3',
    '2022-12-21',
    37500.00,
    37500.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-08 23:51:48',
    '2025-10-28 23:59:33'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '4c7e8eec-5a35-4004-b841-eba4845545d9',
    'HP ELITEBook ',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG83417Z4',
    '2023-01-04',
    37500.00,
    37500.00,
    'active',
    'excellent',
    'Headquarters - Floor 1',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-08 23:49:05',
    '2025-09-09 00:35:07'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '500a7fd0-4ce5-4968-b196-48ed27ae3079',
    'HP ELITEBook ',
    'Laptop',
    'Electronics',
    'Dell',
    '840G4',
    '5CG5357R74',
    '2023-02-23',
    37500.00,
    37500.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-09 00:03:09',
    '2025-09-09 00:33:39'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '512c46a8-bb7a-43b6-a931-509697561986',
    'Dell Latitude ',
    'Laptop',
    'Electronics',
    'Dell',
    '7400',
    'JZMPZY2',
    '2025-09-22',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '4c76e663-593d-477c-b90f-5b026a560f80',
    '61117f75-30c0-4d57-8e48-5a198ed9ef72',
    NULL,
    NULL,
    '32GB RAM 256GH Hard Disk Core i7',
    '2025-09-22 01:27:59',
    '2025-09-22 02:54:56'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '5b83630f-211a-40f9-9c96-09499d9e32a9',
    'HP ELITEBook ',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG6265593',
    '2024-02-05',
    0.00,
    0.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '8GB RAM,\n512GB ssd,\nCorei7',
    '2025-09-09 00:07:59',
    '2025-09-09 00:24:12'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '5c82e2f9-cd1e-4da9-babb-13ef07ccef5f',
    'HP ELITEBook ',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG8341829',
    '2023-03-02',
    37500.00,
    37500.01,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '8GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-09 00:05:02',
    '2025-09-09 00:33:24'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '611f1f1a-23a0-43e4-962d-ee006d93144c',
    'HP ELITEBook ',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG62045GV',
    '2024-02-27',
    0.00,
    0.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nCorei7',
    '2025-09-09 00:12:40',
    '2025-09-13 23:13:38'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '62b17d8b-1246-48e2-b2be-4d9645d60f3b',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG7251214',
    '2025-09-08',
    30000.00,
    30000.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '8GB RAM,\n256GB ssd,\nTouch screen\nCorei5',
    '2025-09-08 23:55:11',
    '2025-10-28 23:59:59'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '639f1fc8-55e6-47cf-aeb5-3c8811d691d8',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG8053V3Y',
    '2023-02-05',
    37500.00,
    37500.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-08 23:58:19',
    '2025-10-29 00:01:28'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '6847bc16-95f9-45e9-8034-6b4993874604',
    'HP EliteBook',
    'Laptop',
    'Electronics',
    'HP',
    '840 G8 Notebook',
    '5CG214BLJY',
    '2025-10-27',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '45db02ef-a523-11f0-a26e-08f1ea8e398e',
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    NULL,
    NULL,
    'Manufacturer:  HP\nModel: HP EliteBook 840 G8 Notebook\nProcessor: Intel Core i7-1185G7 RAM Size: 16GBStorage (ROM): 237GB SSD\nSerial Number: 5CG214BLJY',
    '2025-10-27 05:22:49',
    '2025-10-27 05:22:49'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '690397c3-d5b9-4635-8985-82a3e2b8394c',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG8340J89',
    '2023-02-19',
    37500.00,
    37500.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '8GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-09 00:00:02',
    '2025-10-29 00:02:03'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '7b639e7c-473c-43ac-bd40-a6a808d7e225',
    'Dell',
    'Laptop',
    'Electronics',
    'Dell',
    NULL,
    'P73G001',
    '2022-09-15',
    46980.00,
    46980.00,
    'active',
    'excellent',
    'Turnkey Africa',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    'Core i5',
    '2025-10-29 00:08:27',
    '2025-10-29 00:08:27'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '7e02b1b3-38be-49ce-9eeb-0170f2f86ab3',
    'Lenovo',
    'Laptop',
    'Electronics',
    'Lenovo',
    NULL,
    'FBCCCF5C-5B0B-4E5D-97A0-1AAF52697F43',
    '2017-06-12',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    'Core i3',
    '2025-10-29 00:14:05',
    '2025-10-29 00:14:05'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '800a27bd-653e-4ffa-9bc9-043dc228b584',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG8326D7Y',
    '2022-02-21',
    37500.00,
    37500.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '8GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-09 00:01:56',
    '2025-10-29 00:02:30'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '912f88f5-fbfc-4f69-b41b-4e1246cf968a',
    'Lenovo',
    'Laptop',
    'Electronics',
    'Lenovo',
    NULL,
    'R90M4HLK',
    '2017-05-15',
    46980.00,
    46980.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    'Core i3',
    '2025-09-08 23:36:46',
    '2025-10-29 00:12:13'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'a11e2f38-1463-4ba5-82fc-b11dd5911f2d',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG8192CQ5',
    '2022-12-22',
    37500.00,
    37500.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nTouch screen\nCorei7',
    '2025-09-08 23:56:45',
    '2025-10-29 00:00:33'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'a7656c1a-2bab-4e15-a3ae-37250c444b86',
    'HP ELITEBook',
    'Laptop',
    'Electronics',
    'HP',
    '840 G3',
    '5CG72846B4',
    '2024-02-03',
    0.00,
    0.00,
    'active',
    'excellent',
    'Remote',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'f0207ab0-de7d-466d-978a-bc84473e1c49',
    NULL,
    NULL,
    '8GB RAM,\n256GB ssd,\nCorei7',
    '2025-09-09 00:09:11',
    '2025-10-27 01:56:41'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'aa9dd501-1169-4cd5-b516-fbf85cec16e9',
    'Dell',
    'Laptop',
    'Electronics',
    'Dell',
    'Optiplex 7010',
    'HQ5Z102',
    '2025-10-27',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '3889eb7e-a51f-11f0-a26e-08f1ea8e398e',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    NULL,
    NULL,
    'Manufacturer: (Dell)Model: (Optiplex 7010)Processor: ( Intel Core i5-3470 CPU @ 3.20GHz 3.20GHz )RAM Size: (7.89 GiB)Storage (ROM): (466 GB)Serial Number: (HQ5Z102)',
    '2025-10-27 05:19:09',
    '2025-10-27 05:19:09'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'b5bbfa45-5904-4c3f-8c9d-6dae1b933b0a',
    'HP ElliteBook',
    'Laptop',
    'Electronics',
    'HP',
    '850 G6',
    '5CG9447NCC',
    '2025-09-21',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    'b3a13df1-9343-43c3-bc0e-aa0db50fbe99',
    '249993e1-7e0d-4d1d-8e92-cad9ca730a37',
    NULL,
    NULL,
    '16GB RAM,\n256GB,\nCore i7',
    '2025-09-22 02:30:16',
    '2025-10-29 00:27:29'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'c290ea41-e0ef-4a9a-b809-da3b81a4ec2a',
    'HP EliteBook',
    'Laptop',
    'Electronics',
    'HP',
    '840 G5',
    '5CG91519P4',
    '2025-10-27',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    'e5ee0483-a51d-11f0-a26e-08f1ea8e398e',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    NULL,
    NULL,
    'Manufacturer:HPModel: HP EliteBook 840 G5Processor:Intel(R) Core(TM) i7-8650URAM Size:  16GBStorage (ROM): 512GB SSDSerial Number: 5CG91519P4',
    '2025-10-27 05:26:17',
    '2025-10-27 05:26:17'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'c3b95603-e49a-40a5-8642-5a2af8e36e63',
    'Lenovo',
    'Laptop',
    'Electronics',
    'Lenovo',
    NULL,
    'R90M4KC8',
    '2017-08-01',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    NULL,
    'Core i3',
    '2025-10-29 00:21:19',
    '2025-10-29 00:21:19'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'c6495e5c-b84a-4015-b82b-8c43fd9bc6cd',
    'Lenovo',
    'Laptop',
    'Electronics',
    'Lenovo',
    'm710s',
    'PC0U9VBY',
    '2025-10-24',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '3889eb7e-a51f-11f0-a26e-08f1ea8e398e',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    NULL,
    NULL,
    'Manufacturer: (Lenovo)Model: (m710s)Processor: ( Intel Core i7-7700 CPU @ 3.60GHz × 8 )RAM Size: (7.7 GiB)Storage (ROM): (619.4 GB)Serial Number: (PC0U9VBY)',
    '2025-10-27 05:16:15',
    '2025-10-27 05:19:26'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'da049595-10eb-4a98-89f1-c9c108e81278',
    'HP 270',
    'Laptop',
    'Electronics',
    'HP',
    'G7 Notebook',
    'CND9131FBN',
    '2025-09-19',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    NULL,
    NULL,
    '2025-09-24 02:36:44',
    '2025-10-27 00:58:32'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'df246c6a-20ec-4d7a-8c8e-aa8328ccd008',
    'HP EliteBook',
    'Laptop',
    'Electronics',
    'HP',
    '840 G4',
    '5CG8340FN0',
    '2025-09-23',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '14043440-4ce8-45f9-82ac-da8992c0ada7',
    'd5d42144-030d-4b3c-a587-ada3d7332497',
    NULL,
    NULL,
    '8GB RAM,\n500 GB SSD,\nintel Core i7,\nTouchScreen,\n\"Letter B not Working\"',
    '2025-09-23 03:06:00',
    '2025-09-23 03:15:15'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'f25a2a20-b769-410e-9286-d0f485b09945',
    'Dell Latitude',
    'Laptop',
    'Electronics',
    'Dell',
    '7300',
    'GNK6YY2',
    '2025-09-21',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '9aa48523-2ee8-43af-a198-9b9ec0a2aeff',
    'c6b07ab2-b175-4a74-a3f9-2afeac9b52b7',
    NULL,
    NULL,
    '32GB RAM 256GB core i7',
    '2025-09-22 01:20:04',
    '2025-10-29 00:59:42'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'fb4a1615-6541-4508-84af-3a834652ff4e',
    'HP ELITEBook ',
    'Laptop',
    'Electronics',
    'HP',
    '840G4',
    '5CG8331CBY',
    '2024-02-05',
    0.00,
    0.00,
    'active',
    'excellent',
    'Remote',
    NULL,
    NULL,
    NULL,
    NULL,
    '16GB RAM,\n512GB ssd,\nCorei7',
    '2025-09-09 00:16:21',
    '2025-09-13 23:13:19'
  );
INSERT INTO
  `assets` (
    `id`,
    `name`,
    `type`,
    `category`,
    `manufacturer`,
    `model`,
    `serial_number`,
    `purchase_date`,
    `purchase_price`,
    `current_value`,
    `status`,
    `asset_condition`,
    `location`,
    `assigned_to`,
    `department_id`,
    `warranty_expiry`,
    `last_maintenance`,
    `notes`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'fb4dd60c-2927-4c3c-a5c7-21914876e963',
    'HP ElliteBook',
    'Laptop',
    'Electronics',
    'HP',
    '840 G3',
    '5CG74658K2',
    '2025-09-21',
    0.00,
    0.00,
    'active',
    'excellent',
    'Turnkey Africa',
    '7e868e17-bd17-46d8-9666-7b1fffbd9966',
    'c6b07ab2-b175-4a74-a3f9-2afeac9b52b7',
    NULL,
    NULL,
    '32GB RAM,\n256GB ssd,\nCore i7',
    '2025-09-22 02:16:58',
    '2025-10-29 01:01:58'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: backups
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: departments
# ------------------------------------------------------------

INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    'IT Team',
    'IT Team',
    'Turnkey',
    6,
    2,
    'KSh 1,000,000.00',
    'Eugene Lumala',
    '86116fd2-a524-11f0-a26e-08f1ea8e398e',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '2025-09-28 12:45:24',
    '2025-10-27 00:57:23'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '0f494aa6-a2e8-49c9-a522-36ef7dfe225a',
    'Marketing',
    'Marketing department responsible for brand management, campaigns, and market research at Turnkey Africa.',
    'Turnkey',
    1,
    0,
    'KSh .00',
    'David Mutua',
    '1eb9e711-33c3-493b-bcdb-a3cfcd4a77cd',
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-27 03:39:42'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '249993e1-7e0d-4d1d-8e92-cad9ca730a37',
    'Product Team - Agencify',
    'Product Team',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    '7e868e17-bd17-46d8-9666-7b1fffbd9966',
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    '2025-10-29 00:25:23',
    '2025-10-29 00:34:41'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    'GIS_BANCA_ENGINEERS',
    'GIS_BANCA_ENGINEERS',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    'cb5cc465-a4ed-11f0-a26e-08f1ea8e398e',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '2025-10-09 01:51:50',
    '2025-10-09 07:55:14'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    'Turnkey',
    'Root department: Turnkey',
    'Turnkey',
    0,
    15,
    'KSh 1,423,960.01',
    'Unassigned',
    NULL,
    NULL,
    '2025-09-28 12:45:24',
    '2025-09-08 05:16:01'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '48bce373-a521-11f0-a26e-08f1ea8e398e',
    'LMSORD ENGINEERS',
    'LMSORD ENGINEERS',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    '7ba540e1-a521-11f0-a26e-08f1ea8e398e',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '2025-10-09 08:04:41',
    '2025-10-09 08:11:12'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '518edc29-908a-4f4b-9f58-2fc580f62e69',
    'Human Resource',
    'Human Resources department responsible for recruitment, employee relations, and HR operations at Turnkey Africa.',
    'Turnkey',
    3,
    0,
    'KSh .00',
    'Jane Wanjiku',
    '0d6b1083-54be-4b89-beaf-5a6cff925ef8',
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-31 22:14:45'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '5739d5b7-a80a-4b5b-8cdc-e9bdff9776cf',
    'Delivery Team',
    'Delivery Team',
    'Turnkey',
    0,
    0,
    'KSh .00',
    'Unassigned',
    '0865c1ed-a2a5-11f0-b516-00155d38011b',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '2025-09-08 05:24:08',
    '2025-10-29 00:31:30'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '61117f75-30c0-4d57-8e48-5a198ed9ef72',
    'Engineering Team',
    'Engineering Team',
    'Turnkey',
    0,
    0,
    'KSh .00',
    'Unassigned',
    NULL,
    '6901b725-fd67-4d9f-9c03-9b3cee064e84',
    '2025-09-08 05:01:45',
    '2025-09-08 05:38:24'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '6901b725-fd67-4d9f-9c03-9b3cee064e84',
    'Caava AI',
    'Operations department responsible for day-to-day business operations and process management at Turnkey Africa.',
    'Turnkey',
    2,
    0,
    'KSh .00',
    'Sarah Akinyi',
    'be201788-8e22-4e63-ac95-c3816d726a2c',
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-31 22:15:46'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '75c916f7-0ff5-460b-8055-7eeba640424d',
    'Sales Team',
    'Sales',
    'Turnkey',
    0,
    0,
    'KSh .00',
    'Unassigned',
    NULL,
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    '2025-09-09 02:39:47',
    '2025-09-09 02:39:47'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    'LMS Group',
    'LMS Group',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    'a751e209-a522-11f0-a26e-08f1ea8e398e',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '2025-10-09 08:13:07',
    '2025-10-09 08:28:31'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '7f416e2f-a508-11f0-a26e-08f1ea8e398e',
    'Exco',
    'Executive Managers',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    '1d73d444-3672-4e11-8cd3-7eacb71de9e4',
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    '2025-10-09 05:07:15',
    '2025-10-09 05:07:15'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '96735c8a-4570-45b0-bd87-5bd4bf201702',
    'Support Team',
    'Support Team',
    'Turnkey',
    0,
    0,
    'KSh .00',
    'Unassigned',
    'f8527332-a873-4102-9ff4-c17505eb4e58',
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    '2025-09-08 05:39:15',
    '2025-11-03 03:53:36'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '9f5f8753-f1f2-4351-a38a-a63949e563ce',
    'Product Team',
    'Product Team',
    'Turnkey',
    0,
    0,
    'KSh .00',
    'Unassigned',
    NULL,
    '6901b725-fd67-4d9f-9c03-9b3cee064e84',
    '2025-09-09 02:35:53',
    '2025-09-08 05:57:45'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'a83a6332-acc1-45a9-b5a9-8f2c47487b5f',
    'Operations Team',
    'Operations',
    'Turnkey',
    0,
    0,
    'KSh .00',
    'Unassigned',
    NULL,
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    '2025-09-09 02:39:19',
    '2025-09-09 02:39:19'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'a8c6d194-b55f-484b-91d4-9ec0358fbaa1',
    'Production Team',
    'Production Team',
    'Turnkey',
    0,
    0,
    'KSh .00',
    NULL,
    NULL,
    'a8c6d194-b55f-484b-91d4-9ec0358fbaa1',
    '2025-09-08 04:48:28',
    '2025-09-08 05:15:59'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'aa8e955f-69c6-40d1-9a35-54948620bc9a',
    'Finance & Accounting',
    'Finance department responsible for financial planning, accounting, and budget management at Turnkey Africa.',
    'Turnkey',
    1,
    0,
    'KSh .00',
    'Mike Kamau',
    '643be7ce-4af3-410c-a8f7-0ebfe720d153',
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-27 03:39:32'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'c6b07ab2-b175-4a74-a3f9-2afeac9b52b7',
    'Engineering Team - Agencify',
    'Engineering Team',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    'dbfec091-60bc-4c9a-9064-5e02d210c45e',
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    '2025-10-29 00:35:31',
    '2025-10-29 00:35:31'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'ebccace8-a51f-11f0-a26e-08f1ea8e398e',
    'CRM-EVOLVE',
    'CRM-EVOLVE',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    '48a002a8-a520-11f0-a26e-08f1ea8e398e',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '2025-10-09 07:54:55',
    '2025-10-09 08:01:49'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    'Agencify',
    'Agencify',
    'Turnkey',
    3,
    0,
    'KSh .00',
    'Unassigned',
    NULL,
    NULL,
    '2025-08-31 22:16:33',
    '2025-08-31 22:16:33'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'f0207ab0-de7d-466d-978a-bc84473e1c49',
    'GIS Team',
    'GIS Team',
    'Turnkey Africa',
    0,
    0,
    '$0',
    NULL,
    NULL,
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '2025-10-27 01:29:43',
    '2025-10-27 01:29:43'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'f37c4202-9673-4e2b-a3f9-e9594f82289b',
    'Marketing Team',
    'Marketing',
    'Turnkey',
    0,
    0,
    'KSh .00',
    'Unassigned',
    NULL,
    'eeee7771-ddf7-43c9-9eeb-9c66147e0eeb',
    '2025-09-09 02:40:37',
    '2025-09-09 02:40:37'
  );
INSERT INTO
  `departments` (
    `id`,
    `name`,
    `description`,
    `location`,
    `user_count`,
    `asset_count`,
    `asset_value`,
    `manager`,
    `manager_id`,
    `parent_id`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'fdbba582-e020-4905-b56d-bf7beaa5b6d0',
    'Employee',
    'Users to set departments\n',
    'Turnkey',
    2,
    0,
    'KSh .00',
    'Unassigned',
    NULL,
    NULL,
    '2025-09-07 21:34:50',
    '2025-09-07 21:52:14'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: email_templates
# ------------------------------------------------------------

INSERT INTO
  `email_templates` (
    `id`,
    `name`,
    `subject`,
    `body`,
    `variables`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '656d74cc-a299-11f0-b516-00155d38011b',
    'password_reset',
    'Your Password Reset Code - Caava Group',
    '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>\n  <title>Password Reset Code</title>\n  <style>\n    body {\n      font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, sans-serif;\n      margin: 0;\n      padding: 20px;\n      background-color: #f8fafc;\n      text-align: center;\n      color: #0f172a;\n    }\n    .container {\n      max-width: 520px;\n      margin: 0 auto;\n      background: #ffffff;\n      border-radius: 12px;\n      padding: 40px 30px;\n      box-shadow: 0 10px 24px rgba(2,6,23,0.08);\n    }\n    .logo {\n      width: 64px;\n      height: 64px;\n      background: linear-gradient(135deg, #10b981 0%, #3b82f6 100%);\n      border-radius: 14px;\n      display: inline-flex;\n      align-items: center;\n      justify-content: center;\n      margin-bottom: 16px;\n    }\n    .logo-text {\n      color: white;\n      font-size: 24px;\n      font-weight: 800;\n    }\n    .company {\n      font-size: 20px;\n      font-weight: 800;\n      color: #1f2937;\n    }\n    .subtitle {\n      font-size: 13px;\n      color: #64748b;\n      margin: 6px 0 22px;\n    }\n    .title {\n      font-size: 24px;\n      font-weight: 800;\n      color: #0ea5e9;\n      margin: 12px 0 8px;\n    }\n    .greeting {\n      color: #334155;\n      margin: 8px 0 18px;\n    }\n    .code {\n      display: inline-block;\n      font-family: \"Courier New\", monospace;\n      font-size: 36px;\n      font-weight: 800;\n      letter-spacing: 8px;\n      color: #0f172a;\n      background: #f1f5f9;\n      border: 2px solid #cbd5e1;\n      border-radius: 12px;\n      padding: 14px 18px;\n      margin: 8px 0 14px;\n    }\n    .hint {\n      font-size: 13px;\n      color: #64748b;\n      margin: 8px 0 4px;\n    }\n    .expiry {\n      font-size: 12px;\n      color: #ef4444;\n      font-weight: 700;\n      margin: 4px 0 18px;\n    }\n    .cta {\n      margin: 18px 0 6px;\n    }\n    .button {\n      display: inline-block;\n      background: linear-gradient(135deg, #10b981 0%, #3b82f6 100%);\n      color: #ffffff !important;\n      text-decoration: none;\n      padding: 12px 22px;\n      border-radius: 10px;\n      font-weight: 700;\n      font-size: 14px;\n    }\n    .footer {\n      font-size: 12px;\n      color: #94a3b8;\n      margin-top: 24px;\n      padding-top: 16px;\n      border-top: 1px solid #e5e7eb;\n      line-height: 1.5;\n    }\n    @media (max-width: 480px) {\n      .code { font-size: 28px; letter-spacing: 6px; }\n      .container { padding: 32px 20px; }\n    }\n  </style>\n</head>\n<body>\n  <div class=\"container\">\n    <div class=\"logo\">\n      <div class=\"logo-text\">C</div>\n    </div>\n    <div class=\"company\">Caava Group</div>\n    <div class=\"subtitle\">Assets Management System</div>\n\n    <div class=\"title\">Password Reset</div>\n    <div class=\"greeting\">Hello {{user_name}},</div>\n\n    <div class=\"hint\">Use the code below to reset your password:</div>\n    <div class=\"code\">{{reset_code}}</div>\n\n    <div class=\"expiry\">Expires in 15 minutes</div>\n\n    <div class=\"cta\">\n      <a class=\"button\" href=\"{{reset_link}}\" target=\"_blank\" rel=\"noopener\">Reset Password</a>\n    </div>\n\n    <div class=\"footer\">\n      If you didnâ€™t request this, you can safely ignore this email.<br/>\n      Â© 2025 Caava Group. All rights reserved.\n    </div>\n  </div>\n</body>\n</html>',
    '[\"user_name\", \"reset_code\"]',
    1,
    '2025-10-06 02:46:56',
    '2025-10-09 01:46:21'
  );
INSERT INTO
  `email_templates` (
    `id`,
    `name`,
    `subject`,
    `body`,
    `variables`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'ae77ffca-a2a4-11f0-b516-00155d38011b',
    'welcome_user',
    'Welcome to Caava Group Devices Management System! ðŸŽ‰',
    '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <title>Welcome to Caava Group</title>\n    <style>\n        body {\n            font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, sans-serif;\n            margin: 0;\n            padding: 20px;\n            background-color: #f8fafc;\n            text-align: center;\n        }\n        .container {\n            max-width: 500px;\n            margin: 0 auto;\n            background: white;\n            border-radius: 12px;\n            padding: 40px 30px;\n            box-shadow: 0 4px 15px rgba(0,0,0,0.1);\n        }\n        .logo {\n            width: 60px;\n            height: 60px;\n            background: linear-gradient(135deg, #10b981 0%, #3b82f6 100%);\n            border-radius: 12px;\n            display: inline-flex;\n            align-items: center;\n            justify-content: center;\n            margin-bottom: 20px;\n        }\n        .logo-text {\n            color: white;\n            font-size: 24px;\n            font-weight: bold;\n        }\n        .company {\n            font-size: 20px;\n            font-weight: 700;\n            color: #1f2937;\n            margin-bottom: 10px;\n        }\n        .subtitle {\n            font-size: 14px;\n            color: #6b7280;\n            margin-bottom: 30px;\n        }\n        .welcome-title {\n            font-size: 28px;\n            font-weight: 700;\n            color: #10b981;\n            margin: 20px 0;\n        }\n        .message {\n            font-size: 16px;\n            color: #374151;\n            line-height: 1.6;\n            margin: 20px 0;\n        }\n        .login-box {\n            background: #f0fdf4;\n            border: 2px solid #10b981;\n            border-radius: 8px;\n            padding: 20px;\n            margin: 25px 0;\n        }\n        .login-title {\n            font-size: 18px;\n            font-weight: 600;\n            color: #10b981;\n            margin-bottom: 10px;\n        }\n        .login-url {\n            font-size: 16px;\n            color: #1f2937;\n            word-break: break-all;\n            background: white;\n            padding: 10px;\n            border-radius: 4px;\n            border: 1px solid #d1d5db;\n        }\n        .credentials {\n            background: #fef3c7;\n            border: 1px solid #f59e0b;\n            border-radius: 6px;\n            padding: 15px;\n            margin: 20px 0;\n            text-align: left;\n        }\n        .credentials-title {\n            font-size: 14px;\n            font-weight: 600;\n            color: #92400e;\n            margin-bottom: 10px;\n        }\n        .credential-item {\n            font-size: 14px;\n            color: #374151;\n            margin: 5px 0;\n        }\n        .next-steps {\n            background: #eff6ff;\n            border: 1px solid #3b82f6;\n            border-radius: 6px;\n            padding: 15px;\n            margin: 20px 0;\n            text-align: left;\n        }\n        .next-steps-title {\n            font-size: 14px;\n            font-weight: 600;\n            color: #1e40af;\n            margin-bottom: 10px;\n        }\n        .step {\n            font-size: 14px;\n            color: #374151;\n            margin: 5px 0;\n        }\n        .footer {\n            font-size: 12px;\n            color: #9ca3af;\n            margin-top: 30px;\n            padding-top: 20px;\n            border-top: 1px solid #e5e7eb;\n        }\n        .button {\n            display: inline-block;\n            background: linear-gradient(135deg, #10b981 0%, #3b82f6 100%);\n            color: white;\n            padding: 12px 24px;\n            text-decoration: none;\n            border-radius: 6px;\n            font-weight: 600;\n            margin: 15px 0;\n        }\n    </style>\n</head>\n<body>\n    <div class=\"container\">\n        <div class=\"logo\">\n            <div class=\"logo-text\">C</div>\n        </div>\n        <div class=\"company\">Caava Group</div>\n        <div class=\"subtitle\">Devices Management System</div>\n        \n        <h1 class=\"welcome-title\">Welcome {{user_name}}! ðŸŽ‰</h1>\n        \n        <div class=\"message\">\n            Your account has been successfully created. You can now access the Caava Group Devices Management System to manage your assets and track your requests.\n        </div>\n        \n        <div class=\"login-box\">\n            <div class=\"login-title\">ðŸ”— Access Your Account</div>\n            <div class=\"login-url\">{{site_url}}</div>\n        </div>\n        \n        <div class=\"credentials\">\n            <div class=\"credentials-title\">ðŸ“§ Your Login Credentials:</div>\n            <div class=\"credential-item\"><strong>Email:</strong> {{user_email}}</div>\n            <div class=\"credential-item\"><strong>Password:</strong> {{temporary_password}}</div>\n        </div>\n        \n        <div class=\"next-steps\">\n            <div class=\"next-steps-title\">ðŸš€ Next Steps:</div>\n            <div class=\"step\">1. Click the login URL above or visit the site</div>\n            <div class=\"step\">2. Log in with your email and temporary password</div>\n            <div class=\"step\">3. Change your password in the security settings</div>\n            <div class=\"step\">4. Complete your profile information</div>\n        </div>\n        \n        <div class=\"message\">\n            If you have any questions or need assistance, please contact your system administrator.\n        </div>\n        \n        <div class=\"footer\">\n            <p>Â© 2025 Caava Group. All rights reserved.</p>\n            <p>This is an automated message, please do not reply.</p>\n        </div>\n    </div>\n</body>\n</html>',
    '[\"user_name\", \"user_email\", \"site_url\", \"temporary_password\"]',
    1,
    '2025-10-06 04:07:43',
    '2025-10-09 01:48:53'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: issue_comments
# ------------------------------------------------------------

INSERT INTO
  `issue_comments` (
    `id`,
    `issue_id`,
    `user_id`,
    `user_name`,
    `content`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '018371db-af37-11f0-97d8-08f1ea8e398e',
    'aff327cf-af36-11f0-97d8-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Sostine Waliaula',
    'whats is the progress of my issue',
    '2025-10-22 04:05:22',
    '2025-10-22 04:05:22'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: issues
# ------------------------------------------------------------

INSERT INTO
  `issues` (
    `id`,
    `title`,
    `description`,
    `status`,
    `priority`,
    `category`,
    `reported_by`,
    `assigned_to`,
    `asset_id`,
    `department_id`,
    `estimated_resolution_date`,
    `actual_resolution_date`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '538f9640-f30b-49ec-a5fb-9348cd01b249',
    'Battery Issue',
    'I need my laptop battery replaced because it no longer stores charge and currently functions only when connected to power, so that I can work efficiently without being dependent on a power outlet\r\n\r\nBattery Details:\r\nCT:6EUWV10WY883CX\r\nLet me know when this is possible.',
    'open',
    'critical',
    'Hardware Failure',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    NULL,
    'a7656c1a-2bab-4e15-a3ae-37250c444b86',
    'f0207ab0-de7d-466d-978a-bc84473e1c49',
    NULL,
    NULL,
    '2025-10-27 03:39:58',
    '2025-10-27 03:48:53'
  );
INSERT INTO
  `issues` (
    `id`,
    `title`,
    `description`,
    `status`,
    `priority`,
    `category`,
    `reported_by`,
    `assigned_to`,
    `asset_id`,
    `department_id`,
    `estimated_resolution_date`,
    `actual_resolution_date`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '736b910b-f15a-496f-a110-88b1257ebd56',
    'Memory And RAM',
    'I need an upgrade of my memory and RAM since I am experiencing frequent computer crashes.',
    'open',
    'critical',
    'Upgrade Request',
    'b7b5adb5-5535-4f49-affb-430b25d3c8e1',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    '2025-10-31 06:56:19',
    '2025-10-31 06:56:19'
  );
INSERT INTO
  `issues` (
    `id`,
    `title`,
    `description`,
    `status`,
    `priority`,
    `category`,
    `reported_by`,
    `assigned_to`,
    `asset_id`,
    `department_id`,
    `estimated_resolution_date`,
    `actual_resolution_date`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '91a80fd1-a51c-11f0-a26e-08f1ea8e398e',
    'Mouse problems',
    'Mouse problems',
    'open',
    'medium',
    'Upgrade Request',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    NULL,
    NULL,
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    NULL,
    '2025-10-09 07:30:56',
    '2025-10-09 07:30:56'
  );
INSERT INTO
  `issues` (
    `id`,
    `title`,
    `description`,
    `status`,
    `priority`,
    `category`,
    `reported_by`,
    `assigned_to`,
    `asset_id`,
    `department_id`,
    `estimated_resolution_date`,
    `actual_resolution_date`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'a9698c49-a298-11f0-b516-00155d38011b',
    'in device reporting',
    'test report issue for the new db',
    'in_progress',
    'medium',
    'Hardware Failure',
    'admin-user-id',
    NULL,
    'da049595-10eb-4a98-89f1-c9c108e81278',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    NULL,
    '2025-10-06 02:41:40',
    '2025-10-19 07:43:31'
  );
INSERT INTO
  `issues` (
    `id`,
    `title`,
    `description`,
    `status`,
    `priority`,
    `category`,
    `reported_by`,
    `assigned_to`,
    `asset_id`,
    `department_id`,
    `estimated_resolution_date`,
    `actual_resolution_date`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'aff327cf-af36-11f0-97d8-08f1ea8e398e',
    'Battery Issues',
    'My battery discharges faster making my laptop appear like a deskop. I need a new battery to fix this issue.',
    'open',
    'medium',
    'Replacement Request',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    NULL,
    NULL,
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    NULL,
    '2025-10-22 04:03:05',
    '2025-10-22 04:04:49'
  );
INSERT INTO
  `issues` (
    `id`,
    `title`,
    `description`,
    `status`,
    `priority`,
    `category`,
    `reported_by`,
    `assigned_to`,
    `asset_id`,
    `department_id`,
    `estimated_resolution_date`,
    `actual_resolution_date`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'b362a5ca-a50a-11f0-a26e-08f1ea8e398e',
    'Unable to Access ABSA UG 12C Office Environment',
    'Unable to Access ABSA UG 12C Office Environment',
    'open',
    'medium',
    'Software Issue',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    NULL,
    NULL,
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    NULL,
    '2025-10-09 05:23:01',
    '2025-10-09 05:23:01'
  );
INSERT INTO
  `issues` (
    `id`,
    `title`,
    `description`,
    `status`,
    `priority`,
    `category`,
    `reported_by`,
    `assigned_to`,
    `asset_id`,
    `department_id`,
    `estimated_resolution_date`,
    `actual_resolution_date`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'f9562401-577f-49ba-853f-3a93f052d8ea',
    'Laptop Charger Intermittent Connection and Slow Charging',
    'The laptop charger connects intermittently, sometimes it charges, and other times it doesn’t detect the connection. When it does charge, the charging is very slow and hangs. However, when using a Type-C charger, the laptop charges normally.',
    'open',
    'high',
    'Maintenance',
    '4c76e663-593d-477c-b90f-5b026a560f80',
    NULL,
    '512c46a8-bb7a-43b6-a931-509697561986',
    '61117f75-30c0-4d57-8e48-5a198ed9ef72',
    NULL,
    NULL,
    '2025-10-29 00:42:28',
    '2025-10-29 00:42:28'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mfa_policies
# ------------------------------------------------------------

INSERT INTO
  `mfa_policies` (
    `id`,
    `name`,
    `description`,
    `enabled`,
    `enforcement_level`,
    `target_roles`,
    `exempt_roles`,
    `grace_period_days`,
    `created_at`,
    `updated_at`,
    `created_by`,
    `updated_by`
  )
VALUES
  (
    1,
    'Admin MFA Required',
    'All administrators must have MFA enabled for security',
    1,
    'required',
    '[\"admin\"]',
    NULL,
    7,
    '2025-10-19 04:35:34',
    '2025-10-19 04:35:34',
    'system',
    NULL
  );
INSERT INTO
  `mfa_policies` (
    `id`,
    `name`,
    `description`,
    `enabled`,
    `enforcement_level`,
    `target_roles`,
    `exempt_roles`,
    `grace_period_days`,
    `created_at`,
    `updated_at`,
    `created_by`,
    `updated_by`
  )
VALUES
  (
    2,
    'Manager MFA Recommended',
    'Managers are recommended to enable MFA for enhanced security',
    1,
    'recommended',
    '[\"manager\"]',
    NULL,
    14,
    '2025-10-19 04:35:34',
    '2025-10-19 04:35:34',
    'system',
    NULL
  );
INSERT INTO
  `mfa_policies` (
    `id`,
    `name`,
    `description`,
    `enabled`,
    `enforcement_level`,
    `target_roles`,
    `exempt_roles`,
    `grace_period_days`,
    `created_at`,
    `updated_at`,
    `created_by`,
    `updated_by`
  )
VALUES
  (
    3,
    'User MFA Optional',
    'Regular users may optionally enable MFA',
    1,
    'optional',
    '[\"user\"]',
    NULL,
    0,
    '2025-10-19 04:35:34',
    '2025-10-19 04:35:34',
    'system',
    NULL
  );
INSERT INTO
  `mfa_policies` (
    `id`,
    `name`,
    `description`,
    `enabled`,
    `enforcement_level`,
    `target_roles`,
    `exempt_roles`,
    `grace_period_days`,
    `created_at`,
    `updated_at`,
    `created_by`,
    `updated_by`
  )
VALUES
  (
    4,
    'User MFA Policy',
    'Regular users are required to enable MFA',
    1,
    'optional',
    '[\"user\"]',
    '[]',
    7,
    '2025-10-19 04:44:07',
    '2025-10-28 04:47:02',
    'admin-user-id',
    'admin-user-id'
  );
INSERT INTO
  `mfa_policies` (
    `id`,
    `name`,
    `description`,
    `enabled`,
    `enforcement_level`,
    `target_roles`,
    `exempt_roles`,
    `grace_period_days`,
    `created_at`,
    `updated_at`,
    `created_by`,
    `updated_by`
  )
VALUES
  (
    5,
    'Manager MFA Recommended',
    'Managers are recommended to enable MFA for enhanced security',
    0,
    'recommended',
    '[\"manager\"]',
    '[]',
    7,
    '2025-10-27 00:55:40',
    '2025-10-28 04:47:31',
    'admin-user-id',
    'admin-user-id'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: mfa_policy_violations
# ------------------------------------------------------------

INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    1,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 04:51:13',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    2,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 04:51:22',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    3,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 04:58:10',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    4,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:02:14',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    5,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:02:35',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    6,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:05:47',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    7,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:05:56',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    8,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:06:01',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    9,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:09:11',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    10,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:10:39',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    11,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:13:33',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    12,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:13:40',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    13,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:19:59',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    14,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-19 05:38:53',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    15,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-22 03:19:34',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    16,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-22 03:20:03',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    17,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    'login_without_mfa',
    '2025-10-22 03:57:56',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    18,
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    4,
    'login_without_mfa',
    '2025-10-26 03:07:45',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    19,
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    4,
    'login_without_mfa',
    '2025-10-26 23:55:42',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    20,
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    4,
    'login_without_mfa',
    '2025-10-27 01:45:32',
    0,
    NULL,
    'MFA is required but not enabled'
  );
INSERT INTO
  `mfa_policy_violations` (
    `id`,
    `user_id`,
    `policy_id`,
    `violation_type`,
    `violation_date`,
    `resolved`,
    `resolved_date`,
    `notes`
  )
VALUES
  (
    21,
    '4273684a-89bf-4d96-bdb1-5c06a172b9a4',
    4,
    'login_without_mfa',
    '2025-10-28 04:42:09',
    0,
    NULL,
    'MFA is required but not enabled'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: notifications
# ------------------------------------------------------------

INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '003a7c14-ab29-11f0-8d03-08f1ea8e398e',
    'admin-user-id',
    'New Asset Request Submitted',
    'IT-Team requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-17 00:15:02'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '042fe8dd-ac3e-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Asset Request Submitted',
    'Sostine Waliaula requested Request for Desktop (Monitor).',
    'info',
    0,
    '2025-10-18 09:18:00'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '0702895b-a51f-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:48:31'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '086c52b3-a2a5-11f0-b516-00155d38011b',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-06 04:10:14'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '08abe36c-a523-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:17:12'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '0b363a63-ab0d-11f0-bb86-00155d38011d',
    'admin-user-id',
    'Asset Request Submitted',
    'Your request for Request for Laptop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-17 06:50:41'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '0d8a76af-ab0d-11f0-bb86-00155d38011d',
    '86116fd2-a524-11f0-a26e-08f1ea8e398e',
    'New Asset Request Submitted',
    'IT-Team requested Request for Laptop (Laptop).',
    'info',
    0,
    '2025-10-17 06:50:45'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '0f8d6a6f-a4ee-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 01:58:00'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '1075051b-b26f-4672-81e8-2a43570e154e',
    'admin-user-id',
    'New Issue Reported',
    'Paul Gachau reported a new critical priority issue: \"Memory And RAM\". Please review and assign if needed.',
    'error',
    0,
    '2025-10-31 06:56:23'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '10a934c9-3f48-4368-8be8-e3bbf1d33f73',
    '4c76e663-593d-477c-b90f-5b026a560f80',
    'Issue Reported Successfully',
    'Your issue \"Laptop Charger Intermittent Connection and Slow Charging\" has been reported and is being reviewed.',
    'success',
    1,
    '2025-10-29 00:42:28'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '11062cdf-ab0d-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Asset Request Submitted',
    'IT-Team requested Request for Laptop (Laptop).',
    'info',
    0,
    '2025-10-17 06:50:51'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '14e020ee-a2b2-11f0-b516-00155d38011b',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-06 05:43:38'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '14e6b7a9-a2b2-11f0-b516-00155d38011b',
    'admin-user-id',
    'Issue Created Successfully',
    'Your issue \"fjdnfd\" has been created and is now open. It will be reviewed by the team.',
    'success',
    0,
    '2025-10-06 05:43:38'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '156170b0-4671-4341-809e-bbc31b7d58a6',
    'admin-user-id',
    'New Issue Reported',
    'Sharleen Mochama reported a new critical priority issue: \"Battery Issue\". Please review and assign if needed.',
    'error',
    0,
    '2025-10-27 03:40:00'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '16984d8e-a77e-11f0-b195-08f1ea8e398e',
    'admin-user-id',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-12 08:14:02'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '16ecf699-a77e-11f0-b195-08f1ea8e398e',
    '86116fd2-a524-11f0-a26e-08f1ea8e398e',
    'New Asset Request Submitted',
    'IT-Team requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-12 08:14:02'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '179a749c-a77e-11f0-b195-08f1ea8e398e',
    'admin-user-id',
    'New Asset Request Submitted',
    'IT-Team requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-12 08:14:04'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '1e51dfe2-a51e-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:42:01'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '207090b1-ab1c-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Comment on Asset Request',
    'Sostine Waliaula added a comment to Sostine Waliaula\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:38:40'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '21dd5be2-a522-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:10:45'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '24844c7a-ab1c-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Comment on Asset Request',
    'Sostine Waliaula added a comment to Sostine Waliaula\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:38:46'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '25b9ff7a-ac4f-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Message from Sostine Waliaula Personal',
    'sjgdgsaggagsd',
    'info',
    0,
    '2025-10-19 01:43:03'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '25cb03c6-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-18 07:45:53'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '298f8024-a523-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:18:07'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '29bb47ae-a524-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:25:17'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '29d350b2-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-18 07:46:00'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '2ac6e977-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:46:01'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '2e523995-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:46:07'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '2f9551d7-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:46:10'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '338ed2ea-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:46:16'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '3543d4ef-daee-4033-8686-082453c19965',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'Issue Reported Successfully',
    'Your issue \"Battery Issue\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-27 03:39:58'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '35f63a19-ac3a-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-18 08:50:46'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '388a5d6a-a51f-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:49:55'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '3b87616f-ac3a-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Asset Request Submitted',
    'Sostine Waliaula requested Request for Desktop (Monitor).',
    'info',
    0,
    '2025-10-18 08:50:55'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '3d882e2f-ac4e-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Message from Sostine Waliaula Personal',
    'shdshadsaha',
    'info',
    0,
    '2025-10-19 01:36:34'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '3d9d61b2-106c-42ef-8905-ab0601caac94',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'New User Registration',
    'A new user \"test3\" (hagerty.cars@gmail.com) has registered. Position: CoE Manager, Department: IT Team',
    'info',
    0,
    '2025-11-04 00:29:37'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '4015cd5d-1e10-4b43-9c0d-61db8bf1fac2',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'Welcome to Caava Group Assets Management',
    'Your account has been created. You can now log in with your credentials. Please change your password after logging in for the first time.',
    'info',
    1,
    '2025-10-27 01:30:55'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '44efb120-dfec-432f-8227-301cb6ccc8a7',
    '175b5b6e-2ca7-4f93-bb05-e3a5fe947f61',
    'Welcome to Caava Group Assets Management',
    'Your account has been created. You can now log in with your credentials. Please change your password after logging in for the first time.',
    'info',
    0,
    '2025-11-04 00:29:34'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '45833abb-b531-4c1e-b246-0cf34e683f3b',
    'f06ad83b-7880-486c-abcc-72ba9206baa3',
    'Welcome to Caava Group Assets Management',
    'Your account has been created. You can now log in with your credentials. Please change your password after logging in for the first time.',
    'info',
    0,
    '2025-10-27 02:18:54'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '45dbca50-a523-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:18:55'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '471c8641-aba8-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Test Issue Reported Successfully',
    'Your issue \"Reason for Request *\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-17 15:26:08'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '48a09985-a520-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:57:31'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '49ecab49-ab1f-11f0-bb86-00155d38011d',
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    'Admin Response to Your Asset Request',
    'Admin Hagerty responded to your request for \"Request for Laptop\".',
    'success',
    0,
    '2025-10-17 09:01:18'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '49f88300-aba8-11f0-a366-00155d38011d',
    'admin-user-id',
    'Test New Issue Reported',
    'Sostine Waliaula reported a new medium priority issue: \"Reason for Request *\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-17 15:26:13'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '4bb78f3e-ab1f-11f0-bb86-00155d38011d',
    'admin-user-id',
    'Admin Comment on Asset Request',
    'Admin Hagerty commented on Hiram Mugambi\'s request for \"Request for Laptop\".',
    'success',
    0,
    '2025-10-17 09:01:21'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '4bfc928d-af36-11f0-97d8-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-22 04:00:17'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '4e15223f-af36-11f0-97d8-08f1ea8e398e',
    'admin-user-id',
    'New Asset Request Submitted',
    'Sostine Waliaula requested Request for Desktop (Monitor).',
    'info',
    0,
    '2025-10-22 04:00:21'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '53ddf357-a294-11f0-b516-00155d38011b',
    '9e88c79c-aa5a-4e82-a471-92bc075f6575',
    'New Device Request',
    'IT-Team requested a new device: \"Laptop\".',
    'warning',
    0,
    '2025-10-06 02:10:39'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '54529b14-a294-11f0-b516-00155d38011b',
    '1d73d444-3672-4e11-8cd3-7eacb71de9e4',
    'New Device Request',
    'IT-Team requested a new device: \"Laptop\".',
    'warning',
    0,
    '2025-10-06 02:10:40'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '5463b989-ec02-48f8-a582-c4fba86f3337',
    'b7b5adb5-5535-4f49-affb-430b25d3c8e1',
    'Issue Reported Successfully',
    'Your issue \"Memory And RAM\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-31 06:56:19'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '5e0233b0-ab1f-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Admin Response to Your Asset Request',
    'Admin IT-Team responded to your request for \"Request for Laptop\".',
    'success',
    0,
    '2025-10-17 09:01:51'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '6000de31-a5d4-46b9-9df5-7cc0023a3883',
    'cb5cc465-a4ed-11f0-a26e-08f1ea8e398e',
    'New Asset Request Submitted',
    'Washington Chacha requested RAM (Other).',
    'info',
    1,
    '2025-10-31 00:08:40'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '609bcd4f-ab92-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request is pending review',
    'Your request for \"Request for Laptop\" is pending review by IT-Team.',
    'info',
    0,
    '2025-10-17 12:49:22'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '60b47ee8-ab92-11f0-a366-00155d38011d',
    'admin-user-id',
    'Asset Request is pending review',
    'Sostine Waliaula\'s request for \"Request for Laptop\" is pending review by IT-Team.',
    'info',
    0,
    '2025-10-17 12:49:22'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '618cba1c-f248-4c21-8443-599bde0cf917',
    'f06ad83b-7880-486c-abcc-72ba9206baa3',
    'New Issue Reported',
    'Sharleen Mochama reported a new critical priority issue: \"Battery Issue\". Please review and assign if needed.',
    'error',
    0,
    '2025-10-27 03:40:02'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '628739b4-a51e-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:43:56'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '6398d36e-a4e1-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-09 00:27:18'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '63ed4eb1-a4ee-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 02:00:22'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '657d4e0b-a4e1-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'New Asset Request Submitted',
    'IT-Team requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-09 00:27:21'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '6bc44f20-22c3-466f-ada6-f5bf959ec4db',
    'f8527332-a873-4102-9ff4-c17505eb4e58',
    'Welcome to Caava Group Assets Management',
    'Your account has been created. You can now log in with your credentials. Please change your password after logging in for the first time.',
    'info',
    0,
    '2025-11-03 03:53:15'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '715da567-f459-43e9-bca3-1f8673ca3354',
    'admin-user-id',
    'New Asset Request Submitted',
    'Washington Chacha requested RAM (Other).',
    'info',
    0,
    '2025-10-31 00:08:43'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '72c4eecb-aba8-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-17 15:27:21'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '744b48e6-af36-11f0-97d8-08f1ea8e398e',
    'admin-user-id',
    'New Comment on Asset Request',
    'Sostine Waliaula added a comment to Sostine Waliaula\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-22 04:01:25'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '74b80361-ac3b-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-18 08:59:40'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '761bfb1b-af36-11f0-97d8-08f1ea8e398e',
    'admin-user-id',
    'New Comment on Asset Request',
    'Sostine Waliaula added a comment to Sostine Waliaula\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-22 04:01:28'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '77b03c91-ab1b-11f0-bb86-00155d38011d',
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    'New Comment on Your Asset Request',
    'Zedekiah Ambogo added a comment to your request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:33:56'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '798de8da-a2bc-11f0-b516-00155d38011b',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-06 06:58:02'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '79ac8210-a2bc-11f0-b516-00155d38011b',
    'admin-user-id',
    'Issue Created Successfully',
    'Your issue \"fjdnfd\" has been created and is now open. It will be reviewed by the team.',
    'success',
    0,
    '2025-10-06 06:58:02'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '79b6ccaf-ab1b-11f0-bb86-00155d38011d',
    'a751e209-a522-11f0-a26e-08f1ea8e398e',
    'New Comment on Asset Request',
    'Zedekiah Ambogo added a comment to Hiram Mugambi\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:34:00'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '7a33fdc7-ac3b-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 08:59:50'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '7ba5ff69-a521-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:06:06'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '7c0816b1-aba8-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-17 15:27:37'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '7ce519d0-ab1b-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Comment on Asset Request',
    'Zedekiah Ambogo added a comment to Hiram Mugambi\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:34:05'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '7e2c1e87-ac3b-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 08:59:56'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '7f3ecc06-ac4e-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Message from Sostine Waliaula Personal',
    'xgfdgfd',
    'info',
    0,
    '2025-10-19 01:38:24'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '7fc9d3ec-aba8-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-17 15:27:43'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '81730684-a520-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:59:06'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '830c9913-a508-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'Issue Created Successfully',
    'Your issue \"fjdnfd\" has been created and is now open. It will be reviewed by the team.',
    'success',
    0,
    '2025-10-09 05:07:21'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '84a1fe69-a508-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-09 05:07:24'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '8614d9f5-a524-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:27:52'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '867ce0d7-ab1f-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request has been fulfilled',
    'Your request for \"Request for Laptop\" has been fulfilled by IT-Team.',
    'info',
    0,
    '2025-10-17 09:02:59'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '8bcac4bb-ab1f-11f0-bb86-00155d38011d',
    'admin-user-id',
    'Asset Request has been fulfilled',
    'Sostine Waliaula\'s request for \"Request for Laptop\" has been fulfilled by IT-Team.',
    'info',
    0,
    '2025-10-17 09:03:08'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '8d083c72-a523-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:20:54'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '912a28d4-ab1e-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Comment on Asset Request',
    'Sostine Waliaula added a comment to Sostine Waliaula\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:56:08'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '91718c05-aaed-11f0-bb86-00155d38011d',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    'Asset Request Updated',
    'Your asset request for Request for Other is now fulfilled.',
    'info',
    0,
    '2025-10-17 03:05:23'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '92a45b36-a51c-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-09 07:30:57'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '95aa8f56-ac4f-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Message from Sostine Waliaula Personal',
    'xfgfgfbf',
    'info',
    0,
    '2025-10-19 01:46:11'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '97a9fa97-abaa-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-17 15:42:42'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '9ba36e87-a51e-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:45:31'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    '9faa1ec8-84e0-439b-ac97-7254ad3e5791',
    'f06ad83b-7880-486c-abcc-72ba9206baa3',
    'New Issue Reported',
    'Titus Bundi reported a new high priority issue: \"Laptop Charger Intermittent Connection and Slow Charging\". Please review and assign if needed.',
    'warning',
    0,
    '2025-10-29 00:42:31'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'a00bcc6a-a4e8-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'Asset Assignment Update',
    'Asset tgsh has been assigned to Hagerty.',
    'info',
    0,
    '2025-10-09 01:19:06'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'a25c5973-abaa-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-17 15:43:00'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'a3886206-ab09-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request is pending review',
    'Your request for \"Request for Laptop\" is pending review by IT-Team.',
    'info',
    0,
    '2025-10-17 06:26:19'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'a565451b-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-18 07:49:27'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'a65de38e-abaa-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-17 15:43:07'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'a736055f-a51d-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:38:41'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'a75251dc-a522-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:14:29'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'aaf21bac-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:49:36'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'ab4d214d-a520-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:00:17'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'aede95b0-ac31-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:49:43'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'aff42890-af36-11f0-97d8-08f1ea8e398e',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-22 04:03:05'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b1f1cd83-af36-11f0-97d8-08f1ea8e398e',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-22 04:03:08'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b36367c3-a50a-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'Issue Created Successfully',
    'Your issue \"fjdnfd\" has been created and is now open. It will be reviewed by the team.',
    'success',
    0,
    '2025-10-09 05:23:01'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b39c2168-a507-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'Issue Created Successfully',
    'Your issue \"fjdnfd\" has been created and is now open. It will be reviewed by the team.',
    'success',
    0,
    '2025-10-09 05:01:33'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b4ab40fb-af36-11f0-97d8-08f1ea8e398e',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-22 04:03:13'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b5292edb-a50a-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-09 05:23:04'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b55f8bf9-ab9a-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-17 13:49:00'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b5ac9a74-a521-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:07:44'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b6c98d30-5faa-4fce-b6d5-4929bdb0341e',
    '0d580fe9-d4d3-4b2a-9368-4a7ec74fd752',
    'Welcome to Caava Group Assets Management',
    'Your account has been created. You can now log in with your credentials. Please change your password after logging in for the first time.',
    'info',
    0,
    '2025-11-03 22:56:12'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b78e1d2b-ab1e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Admin Response to Your Asset Request',
    'Admin IT-Team responded to your request for \"Request for Laptop\".',
    'success',
    0,
    '2025-10-17 08:57:12'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b81e3151-a294-11f0-b516-00155d38011b',
    '9e88c79c-aa5a-4e82-a471-92bc075f6575',
    'New Device Request',
    'IT-Team requested a new device: \"Desktop\".',
    'warning',
    0,
    '2025-10-06 02:13:27'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'b82fb6e5-a294-11f0-b516-00155d38011b',
    '1d73d444-3672-4e11-8cd3-7eacb71de9e4',
    'New Device Request',
    'IT-Team requested a new device: \"Desktop\".',
    'warning',
    0,
    '2025-10-06 02:13:27'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'bb75082f-aaed-11f0-bb86-00155d38011d',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    'Asset Request Updated',
    'Your asset request for Request for Other is now pending.',
    'info',
    0,
    '2025-10-17 03:06:33'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'bcc2af15-f45a-4d0b-a3ff-49842567dae5',
    '4273684a-89bf-4d96-bdb1-5c06a172b9a4',
    'Welcome to Caava Group Assets Management',
    'Your account has been created. You can now log in with your credentials. Please change your password after logging in for the first time.',
    'info',
    0,
    '2025-10-28 00:34:46'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'bf99a43f-ab9a-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Asset Request Submitted',
    'Sostine Waliaula requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-17 13:49:17'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'c03d9bbc-a507-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'Issue Created Successfully',
    'Your issue \"fjdnfd\" has been created and is now open. It will be reviewed by the team.',
    'success',
    0,
    '2025-10-09 05:01:54'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'c135e86f-a506-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-09 04:54:46'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'c20a8563-a506-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'Issue Created Successfully',
    'Your issue \"fjdnfd\" has been created and is now open. It will be reviewed by the team.',
    'success',
    0,
    '2025-10-09 04:54:48'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'c2129bfe-a507-11f0-a26e-08f1ea8e398e',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-09 05:01:57'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'c50cc50b-245a-4d32-881d-c2cd99c7522c',
    'admin-user-id',
    'New User Registration',
    'A new user \"test3\" (hagerty.cars@gmail.com) has registered. Position: CoE Manager, Department: IT Team',
    'info',
    0,
    '2025-11-04 00:29:37'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'c71c0d29-a4ea-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 01:34:30'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'c78ee663-f1a8-4565-8657-d5e6016cf22b',
    'f06ad83b-7880-486c-abcc-72ba9206baa3',
    'New Issue Reported',
    'Paul Gachau reported a new critical priority issue: \"Memory And RAM\". Please review and assign if needed.',
    'error',
    0,
    '2025-10-31 06:56:24'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'cad42fa1-b4ce-46f3-87ad-8ed5ecfb1aee',
    'admin-user-id',
    'New User Registration',
    'A new user \"test2\" (test2@turnkeyafrica.com) has registered. Position: Customer Management, Department: Sales Team',
    'info',
    0,
    '2025-11-04 00:18:43'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'cb3df103-ac32-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-18 07:57:40'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'cb5e324c-a4ed-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 01:56:06'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'ccc00390-ab8f-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request is pending review',
    'Your request for \"Request for Laptop\" is pending review by IT-Team.',
    'info',
    0,
    '2025-10-17 12:30:55'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'ce73bd16-ab90-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request has been fulfilled',
    'Your request for \"Request for Laptop\" has been fulfilled by IT-Team.',
    'info',
    0,
    '2025-10-17 12:38:07'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'ce840179-ab90-11f0-a366-00155d38011d',
    'admin-user-id',
    'Asset Request has been fulfilled',
    'Sostine Waliaula\'s request for \"Request for Laptop\" has been fulfilled by IT-Team.',
    'info',
    0,
    '2025-10-17 12:38:07'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'cf1af1b3-ac35-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-18 08:19:15'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd11729d4-ac32-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:57:50'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd1ca6991-ab1e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Admin Response to Your Asset Request',
    'Admin IT-Team responded to your request for \"Request for Laptop\".',
    'success',
    0,
    '2025-10-17 08:57:56'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd2b6e435-ab0e-11f0-bb86-00155d38011d',
    'admin-user-id',
    'Asset Request Submitted',
    'Your request for Request for Laptop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-17 07:03:26'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd2d6b0c6-a520-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:01:23'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd326dcb9-0bc1-4d8e-b138-aaeb34891da2',
    'admin-user-id',
    'New Issue Reported',
    'Titus Bundi reported a new high priority issue: \"Laptop Charger Intermittent Connection and Slow Charging\". Please review and assign if needed.',
    'warning',
    0,
    '2025-10-29 00:42:29'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd35b74fe-ab8f-11f0-a366-00155d38011d',
    'admin-user-id',
    'Asset Request is pending review',
    'Sostine Waliaula\'s request for \"Request for Laptop\" is pending review by IT-Team.',
    'info',
    0,
    '2025-10-17 12:31:06'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd4666a84-ac32-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 07:57:56'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd4b7454e-ac35-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 08:19:25'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd52ee328-ab0e-11f0-bb86-00155d38011d',
    '86116fd2-a524-11f0-a26e-08f1ea8e398e',
    'New Asset Request Submitted',
    'IT-Team requested Request for Laptop (Laptop).',
    'info',
    0,
    '2025-10-17 07:03:30'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd6f94ab0-ac3b-11f0-a366-00155d38011d',
    'admin-user-id',
    'Issue Reported Successfully',
    'Your issue \"fjdnfd\" has been reported and is being reviewed.',
    'success',
    0,
    '2025-10-18 09:02:25'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd742fc0c-a2b0-11f0-b516-00155d38011b',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-06 05:34:45'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd7f6d2d0-ac35-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 08:19:30'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd885bb7d-e519-44ca-a7e7-197586a0e0d4',
    '0701ffe5-a51f-11f0-a26e-08f1ea8e398e',
    'Asset Request Submitted',
    'Your request for RAM has been submitted and is pending review.',
    'success',
    0,
    '2025-10-31 00:08:37'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd961f272-ab0e-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Asset Request Submitted',
    'IT-Team requested Request for Laptop (Laptop).',
    'info',
    0,
    '2025-10-17 07:03:37'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'd98062b9-a4de-11f0-a26e-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Device Assigned',
    'You have been assigned the asset tgsh (SN: fdsgdgdsd).',
    'info',
    0,
    '2025-10-09 00:09:07'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'dc014479-ac3b-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported - fjdnfd',
    'IT-Team has reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 09:02:34'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'de916ebc-ab95-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request Submitted',
    'Your request for Request for Laptop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-17 13:14:22'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'df793c98-ac3b-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Issue Reported',
    'IT-Team reported a new medium priority issue: \"fjdnfd\". Please review and assign if needed.',
    'info',
    0,
    '2025-10-18 09:02:40'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'e039c5cd-a522-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:16:04'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'e03e2b5f-ab1d-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Comment on Asset Request',
    'Sostine Waliaula added a comment to Sostine Waliaula\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:51:11'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'e4e5931e-ab95-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Asset Request Submitted',
    'Sostine Waliaula requested Request for Laptop (Laptop).',
    'info',
    0,
    '2025-10-17 13:14:32'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'e542506d-a51e-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:47:35'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'e5ee71da-a51d-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 07:40:26'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'e6a7bba1-d1c2-4200-8e48-5473cd682f00',
    'f06ad83b-7880-486c-abcc-72ba9206baa3',
    'New Asset Request Submitted',
    'Washington Chacha requested RAM (Other).',
    'info',
    0,
    '2025-10-31 00:08:45'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'e81d9be0-ab1c-11f0-bb86-00155d38011d',
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    'New Comment on Your Asset Request',
    'Zedekiah Ambogo added a comment to your request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:44:15'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'ea88dd86-a8f0-11f0-b195-08f1ea8e398e',
    'admin-user-id',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-14 04:28:30'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'eb564865-a8f0-11f0-b195-08f1ea8e398e',
    '86116fd2-a524-11f0-a26e-08f1ea8e398e',
    'New Asset Request Submitted',
    'IT-Team requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-14 04:28:32'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'eba5ea95-ab1c-11f0-bb86-00155d38011d',
    'admin-user-id',
    'New Comment on Asset Request',
    'Zedekiah Ambogo added a comment to Hiram Mugambi\'s request for \"Request for Laptop\".',
    'info',
    0,
    '2025-10-17 08:44:20'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'ecd9e539-a8f0-11f0-b195-08f1ea8e398e',
    'admin-user-id',
    'New Asset Request Submitted',
    'IT-Team requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-14 04:28:34'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'f12b3523-16f6-436d-9395-683e7c1810bf',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'New User Registration',
    'A new user \"test2\" (test2@turnkeyafrica.com) has registered. Position: Customer Management, Department: Sales Team',
    'info',
    0,
    '2025-11-04 00:18:43'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'f4fef4fe-ab98-11f0-a366-00155d38011d',
    'admin-user-id',
    'New Comment on Asset Request',
    'Sostine Waliaula added a comment to Sostine Waliaula\'s request for \"Request for Monitor\".',
    'info',
    0,
    '2025-10-17 13:36:28'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'f74086e9-a523-11f0-a26e-08f1ea8e398e',
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'Welcome to Caava Group!',
    'Your account has been created successfully. Check your email for login details.',
    'success',
    0,
    '2025-10-09 08:23:53'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'fd29de93-ab28-11f0-8d03-08f1ea8e398e',
    'admin-user-id',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-17 00:14:57'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'fe2cba11-ab28-11f0-8d03-08f1ea8e398e',
    '86116fd2-a524-11f0-a26e-08f1ea8e398e',
    'New Asset Request Submitted',
    'IT-Team requested Request for Desktop (Desktop).',
    'info',
    0,
    '2025-10-17 00:14:59'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'fe9f5838-826e-4dde-b6eb-26caabe59afb',
    'e0b59757-ad10-4386-a151-1991ed7bad53',
    'Welcome to Caava Group Assets Management',
    'Your account has been created. You can now log in with your credentials. Please change your password after logging in for the first time.',
    'info',
    0,
    '2025-11-04 00:18:35'
  );
INSERT INTO
  `notifications` (
    `id`,
    `user_id`,
    `title`,
    `message`,
    `type`,
    `is_read`,
    `created_at`
  )
VALUES
  (
    'fede285e-ac3d-11f0-a366-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'Asset Request Submitted',
    'Your request for Request for Desktop has been submitted and is pending review.',
    'success',
    0,
    '2025-10-18 09:17:51'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: password_reset_tokens
# ------------------------------------------------------------

INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '114f56e8-a29e-11f0-b516-00155d38011b',
    'admin-user-id',
    '',
    '694105',
    '2025-10-06 03:35:22',
    0,
    '2025-10-06 03:20:22'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '17f579e8-b593-11f0-a66a-08f1ea8e398e',
    'cb5cc465-a4ed-11f0-a26e-08f1ea8e398e',
    'a7dfa6be26cf1de7f991c6f46d5620820941f10b46dd64caf344525e60531703',
    '796100',
    '2025-10-30 06:34:38',
    1,
    '2025-10-30 06:19:38'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '19afc30d-a4e1-11f0-a26e-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    '961d683c49de468018c2650f6335723c3de68fa875a9bf611c2bef17a55b04f8',
    '372844',
    '2025-10-09 00:40:14',
    1,
    '2025-10-09 00:25:14'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '32db3101-b309-11f0-a66a-08f1ea8e398e',
    '4c76e663-593d-477c-b90f-5b026a560f80',
    'dd743b30c5997a7eceda83d31177c5303c2110694b23486dfacbb765f4c1b50d',
    '839208',
    '2025-10-27 01:02:31',
    0,
    '2025-10-27 00:47:31'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '44e9ca39-a4f0-11f0-a26e-08f1ea8e398e',
    '1d73d444-3672-4e11-8cd3-7eacb71de9e4',
    'be4ccd72dd3222a5dfc93e541b1f5a5398b8dd3d58ea573067bf1812e87ee3c1',
    '781457',
    '2025-10-09 02:28:49',
    1,
    '2025-10-09 02:13:49'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '83c3ee0d-af37-11f0-97d8-08f1ea8e398e',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'fbb16266d8a039db099fc91a6ca7b7d769aa1cb7521c2447a929912857441606',
    '901460',
    '2025-10-22 04:24:00',
    0,
    '2025-10-22 04:09:00'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '8988bcf4-b660-11f0-a66a-08f1ea8e398e',
    'b7b5adb5-5535-4f49-affb-430b25d3c8e1',
    '094765ff1b9ef6d43fdd35282bf145813f9155008777c38c8c8a9c32fdde660b',
    '464780',
    '2025-10-31 07:05:15',
    1,
    '2025-10-31 06:50:15'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    '9cb50bd1-ab0e-11f0-bb86-00155d38011d',
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    '72b01c89f095f8106ecca81ce0178a8299aa919dfb74d0959aefa3f7d315109d',
    '516115',
    '2025-10-17 07:16:55',
    1,
    '2025-10-17 07:01:55'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    'd28b4ab0-b499-11f0-a66a-08f1ea8e398e',
    '4c76e663-593d-477c-b90f-5b026a560f80',
    'a666d5d5ce23990d984559cb0f3fda70a06c40dbfccc0a924f6b51580ff8b03c',
    '505993',
    '2025-10-29 00:50:17',
    1,
    '2025-10-29 00:35:17'
  );
INSERT INTO
  `password_reset_tokens` (
    `id`,
    `user_id`,
    `token`,
    `code`,
    `expires_at`,
    `used`,
    `created_at`
  )
VALUES
  (
    'ec4beed7-a29b-11f0-b516-00155d38011b',
    'admin-user-id',
    '71d19e95e350e89709209d940d6a0f5fc87ea885e96768834ce3e849d67bc692',
    '000000',
    '2025-10-07 03:05:01',
    0,
    '2025-10-06 03:05:01'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_mfa_compliance
# ------------------------------------------------------------

INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    1,
    'admin-user-id',
    1,
    1,
    '2025-11-04 00:49:44',
    '2025-10-26 04:42:07',
    NULL,
    0,
    '2025-10-19 04:42:07',
    '2025-11-04 00:49:44'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    2,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    4,
    1,
    '2025-10-28 04:49:47',
    '2025-10-21 04:45:32',
    NULL,
    0,
    '2025-10-19 04:45:32',
    '2025-10-28 04:49:47'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    3,
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    3,
    1,
    '2025-10-28 04:49:47',
    NULL,
    NULL,
    0,
    '2025-10-19 04:45:32',
    '2025-10-28 04:49:47'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    7,
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    4,
    0,
    NULL,
    '2025-10-28 03:07:45',
    NULL,
    0,
    '2025-10-26 03:07:45',
    '2025-10-26 03:07:45'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    8,
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    3,
    0,
    NULL,
    NULL,
    NULL,
    0,
    '2025-10-26 03:07:45',
    '2025-10-26 03:07:45'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    9,
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    4,
    0,
    NULL,
    '2025-10-28 23:55:42',
    NULL,
    0,
    '2025-10-26 23:55:42',
    '2025-10-26 23:55:42'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    10,
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    3,
    0,
    NULL,
    NULL,
    NULL,
    0,
    '2025-10-26 23:55:42',
    '2025-10-26 23:55:42'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    11,
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    4,
    1,
    '2025-10-27 03:28:22',
    '2025-11-03 00:45:32',
    NULL,
    0,
    '2025-10-27 01:45:32',
    '2025-10-27 03:28:22'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    12,
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    3,
    1,
    '2025-10-27 03:28:22',
    NULL,
    NULL,
    0,
    '2025-10-27 01:45:32',
    '2025-10-27 03:28:22'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    13,
    '4273684a-89bf-4d96-bdb1-5c06a172b9a4',
    4,
    1,
    '2025-11-03 05:43:57',
    '2025-11-04 03:42:09',
    NULL,
    0,
    '2025-10-28 04:42:09',
    '2025-11-03 05:43:57'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    14,
    '4273684a-89bf-4d96-bdb1-5c06a172b9a4',
    3,
    1,
    '2025-11-03 05:43:57',
    NULL,
    NULL,
    0,
    '2025-10-28 04:42:09',
    '2025-11-03 05:43:57'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    15,
    '4c76e663-593d-477c-b90f-5b026a560f80',
    3,
    1,
    '2025-10-30 01:26:28',
    NULL,
    NULL,
    0,
    '2025-10-29 00:36:17',
    '2025-10-30 01:26:28'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    16,
    '4c76e663-593d-477c-b90f-5b026a560f80',
    4,
    1,
    '2025-10-30 01:26:28',
    '2025-11-04 23:36:17',
    NULL,
    0,
    '2025-10-29 00:36:17',
    '2025-10-30 01:26:28'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    17,
    'cb5cc465-a4ed-11f0-a26e-08f1ea8e398e',
    2,
    1,
    '2025-10-31 00:01:41',
    '2025-11-13 05:20:28',
    NULL,
    0,
    '2025-10-30 06:20:28',
    '2025-10-31 00:01:41'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    18,
    '63ec8458-a4ee-11f0-a26e-08f1ea8e398e',
    3,
    1,
    '2025-10-31 10:36:41',
    NULL,
    NULL,
    0,
    '2025-10-31 00:01:43',
    '2025-10-31 10:36:41'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    19,
    '63ec8458-a4ee-11f0-a26e-08f1ea8e398e',
    4,
    1,
    '2025-10-31 10:36:41',
    '2025-11-06 23:01:43',
    NULL,
    0,
    '2025-10-31 00:01:43',
    '2025-10-31 10:36:41'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    20,
    'b7b5adb5-5535-4f49-affb-430b25d3c8e1',
    3,
    1,
    '2025-10-31 06:51:53',
    NULL,
    NULL,
    0,
    '2025-10-31 06:51:53',
    '2025-10-31 06:51:53'
  );
INSERT INTO
  `user_mfa_compliance` (
    `id`,
    `user_id`,
    `policy_id`,
    `is_compliant`,
    `compliance_date`,
    `grace_period_end`,
    `last_reminder_sent`,
    `reminder_count`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    21,
    'b7b5adb5-5535-4f49-affb-430b25d3c8e1',
    4,
    1,
    '2025-10-31 06:51:53',
    '2025-11-07 05:51:53',
    NULL,
    0,
    '2025-10-31 06:51:53',
    '2025-10-31 06:51:53'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_mfa_factors
# ------------------------------------------------------------

INSERT INTO
  `user_mfa_factors` (
    `id`,
    `user_id`,
    `factor_id`,
    `factor_type`,
    `friendly_name`,
    `secret`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '04e9acf4-b49f-11f0-a66a-08f1ea8e398e',
    '4c76e663-593d-477c-b90f-5b026a560f80',
    '988c663e-7ef1-471f-ac60-e312b5a4321b',
    'totp',
    'Authenticator',
    'G5CESRSIGVRCMI26NBJFW62VMI6HSIZDPE5G4I2DPV5DUOD3ORGA',
    0,
    '2025-10-29 01:12:29',
    '2025-10-29 01:12:29'
  );
INSERT INTO
  `user_mfa_factors` (
    `id`,
    `user_id`,
    `factor_id`,
    `factor_type`,
    `friendly_name`,
    `secret`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '2b6c7c75-b3f3-11f0-a66a-08f1ea8e398e',
    '4273684a-89bf-4d96-bdb1-5c06a172b9a4',
    '7455e279-947e-4f4f-8ac3-5fa830793061',
    'totp',
    'Authenticator',
    'OR3WO5JRHRBFOMBRGZVTMKLSNQXDG4LZJZAV2KCUKRMFA43BINCA',
    0,
    '2025-10-28 04:42:21',
    '2025-10-28 04:42:21'
  );
INSERT INTO
  `user_mfa_factors` (
    `id`,
    `user_id`,
    `factor_id`,
    `factor_type`,
    `friendly_name`,
    `secret`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    '648bd316-b312-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'de8284d1-c781-43d4-ae67-aed24c188e1c',
    'totp',
    'Authenticator',
    'NVGVEVCBGAZCGTLGO42DA4JIJNTSIVK6JB3SS3Z4GZJU4NJMIY4A',
    0,
    '2025-10-27 01:53:20',
    '2025-10-27 03:32:07'
  );
INSERT INTO
  `user_mfa_factors` (
    `id`,
    `user_id`,
    `factor_id`,
    `factor_type`,
    `friendly_name`,
    `secret`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'a38b7e10-b253-11f0-a66a-08f1ea8e398e',
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    '24816743-bfc8-43b9-a135-b6ed066e118c',
    'totp',
    'Authenticator',
    'EFDUU6RBJBZG6KTQK5AS6WBBIA4UG3JVJRNGGNCHG5PDQMZVJNFQ',
    0,
    '2025-10-26 03:07:53',
    '2025-10-26 03:07:53'
  );
INSERT INTO
  `user_mfa_factors` (
    `id`,
    `user_id`,
    `factor_id`,
    `factor_type`,
    `friendly_name`,
    `secret`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'f628e018-ac67-11f0-a366-00155d38011d',
    'admin-user-id',
    '1eb29067-1d70-4b7e-8b9e-af21786c0506',
    'totp',
    'Authenticator',
    'GI4EOVLWNY5C622GGJNEQMLJGUYGEJCNPFLV23BTNZTGI6RDLAXQ',
    1,
    '2025-10-19 04:40:41',
    '2025-10-19 04:41:19'
  );
INSERT INTO
  `user_mfa_factors` (
    `id`,
    `user_id`,
    `factor_id`,
    `factor_type`,
    `friendly_name`,
    `secret`,
    `is_active`,
    `created_at`,
    `updated_at`
  )
VALUES
  (
    'f8c2df95-b301-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    'c2d8dbd3-b512-4bcd-984c-58825db1405f',
    'totp',
    'Authenticator',
    'INHTG4TJHZDW4MTTMYXVOU3BHQYDS7JUH4VHUYSBMVVTST3DHB4Q',
    1,
    '2025-10-26 23:55:47',
    '2025-10-26 23:57:44'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: user_recovery_codes
# ------------------------------------------------------------

INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '0f491996-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    'cd93daee06aa5f29aed5fe56f3e881db4b51458f3e1a1a853a656b135a1ba494',
    1,
    '2025-10-19 04:42:16',
    '2025-10-19 04:41:23'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '1375464d-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'a3f15397a3d02bac6f5272073ad0ea15791122c2897af6816e0dbb6fefa94e45',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '137548ef-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    '43b17f3cd83e42e687596103024c4d6d5f074f548015a7ea962dd44c8771e33d',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '1375496f-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'ad852c7aa27981676d7ac57cc6b151868973c3e8556645ea9d238d392f7d63ad',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '13754a22-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'b7037f4f43b09437abed4b8f1426a5458104726cc0c9e4734537fc423a28bb2f',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '13754aa0-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'bbae6105a1920b101644bd96b3719d5e8ae9961bb69f4da80b205001f6a40e09',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '13754b14-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    '5a2a31015f2d8cab8ba5724f22fb84c563fdd4a119fdb20f60188637cb4ded7d',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '13754bef-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'b9038cbaf92877dd43144c7a3a4732465e63358b98b840fa0eda1a96b8ea104f',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '13754c63-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    '8a02b10b27c5e35db3ff1f88dab5aa5a97b3ce365e24d581a2ddbec9d2ace2c1',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '13754cce-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'fdcc00840d43e549b886c033f1a3efc96f1e4f39e8bfa7ba60e09407029034ad',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '13754d3a-b313-11f0-a66a-08f1ea8e398e',
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'b48e22ea885fe7a3a3b31d0dcab151e86fa545f58fcc64e45c7b93d01d25f52d',
    0,
    NULL,
    '2025-10-27 01:58:14'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f87423-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    'a144e5a669f447bbd5e6da8da1fe06eeadac14663083162e43eace3a38f80ae5',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f87a40-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    'd4e799c3967839eb732ebf42b662bdb61621ea09d3cad8eb8123aa5949f709c1',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f87c2a-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    '85e12347345ffcbf840217c4b5d989781072212ed65fb3343278d280810e7bd9',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f87ed3-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    '83c751cd27d8fc85fa46d55c3bc129561a3205d905a26668925545d7a26dc01a',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f880b0-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    'f428e26728d1652ea0df1de78113b6f23bb72e6b2b1e838e929f976bb50960e2',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f88537-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    'b9389a6c62e84b880267264eab619deabc3694be11a5de162566086571af97d4',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f88728-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    '54f66a17ad37e5846d0e7d3d5baa9a043de5482d6f6cc499d08345e1db5f60d4',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f8889a-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    '461316bf1d08b34a4956e51f8fe07951d6515439d1193ef315d87a4a7c6cbefc',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f889fb-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    'fa5ea6ac9e85a9e5a773574ea36e8c5bad428b4b7796eb8bacf5fd480df1d9dc',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '31f88b6a-ac68-11f0-a366-00155d38011d',
    'admin-user-id',
    'c78ab1e3b69f76ca57eb8461993323a9c8d2d064b2398210866cbffa6c71434a',
    0,
    NULL,
    '2025-10-19 04:42:21'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e7983e7-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '06d90ed7392412a2ff603dc45b02f1ccea94348e0f8debe80124d09f23fa9e13',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e7985d8-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    'a45fdd4f9d294afb1439861012fdc255440b66e06e062c5ac08ad6cd05404302',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e79864b-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '5233bb220e80f8fe76a074049ab820c895aaaf1073774327d28281f54fbf433f',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e7986ba-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '666f6e68ff3c7a75ce1ff2bf3531cbb8af92f5c38b66379ea25929acf154ac82',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e798730-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '7e84206103a989ec6eb9926a801c8e611e1f6025fb80396ab7ae0ec4077a35ec',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e798799-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '0bdfe0f2de2e8ea795275be026389d2d2d5b58678a2c295dc1a0d35e299276e5',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e798813-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '6b908caefa2b21b5ef4e0f6fa9055d7e906531cb6447f38f35320a1ea57e805e',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e798879-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '46baae2a69310dd3acf4b33b07914b6c39ad5df78d01b929b58f53a71f55abcc',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e7988da-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    '3bb2ee73e262a0053510554f01e9df0fd779c2731147066d2d63b3c3500d1117',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );
INSERT INTO
  `user_recovery_codes` (
    `id`,
    `user_id`,
    `code_hash`,
    `is_used`,
    `used_at`,
    `created_at`
  )
VALUES
  (
    '3e798933-b302-11f0-a66a-08f1ea8e398e',
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    'c4711814769698acaaaaf481a2f586cfefa6a9c26e089ef7c110e6290b153063',
    0,
    NULL,
    '2025-10-26 23:57:44'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: users
# ------------------------------------------------------------

INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '045b78e6-1730-4f95-ade8-ab15b9b8d8b7',
    'zedekiah.ambogo@caavagroup.com',
    '$2a$10$dm6SgbkqfpccUehmm49ai.dt5IIa.iH1uSfYmVVSxLHi3Iprd0ULy',
    'Zedekiah Ambogo',
    'user',
    '61117f75-30c0-4d57-8e48-5a198ed9ef72',
    '',
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-09-07 21:48:35',
    '2025-10-22 02:38:23',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '04f1dff6-28c5-4e9b-bb1f-ca4e6ed5b17c',
    'anthony.mwangi@turnkeyafrica.com',
    '$2a$10$aLcp7CqbvsjDFMz.639EPeVnmOYbQFn8fV5sxsKHpWMu7WpNM93jK',
    'Anthony Mwangi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:35',
    '2025-09-07 21:47:35',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '0701ffe5-a51f-11f0-a26e-08f1ea8e398e',
    'washington.jabuya@turnkeyafrica.com',
    '$2a$10$ZVWAKU.4hPI8Rsq6XsLVKORY9QmOoXpW3ocY9hV.KM0BYmF3G23US',
    'Washington Chacha',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0700195379',
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-10-09 07:48:31',
    '2025-10-09 07:48:31',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '08ab7a9c-a523-11f0-a26e-08f1ea8e398e',
    'christopher.lijoodi@turnkeyafrica.com',
    '$2a$10$hXlCWy19ZdexEfHQeyVuF.tD3m5bmgbqFkv0PATov.w7RzM3wlIWW',
    'Christopher Lijoodi',
    'user',
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    NULL,
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 08:17:12',
    '2025-10-09 08:17:12',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '0b4557e0-5b0f-4eff-9c40-57fb73a91007',
    'brian.kipchirchir@turnkeyafrica.com',
    '$2a$10$TvkXZPz3K0ZeGAePF2L02evISJ1UzCXIqklMFvNASxjDOkeQUKoEy',
    'Brian Kipchirchir',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:40',
    '2025-09-07 21:47:40',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '0d580fe9-d4d3-4b2a-9368-4a7ec74fd752',
    'test@turnkeyafrica.com',
    '$2a$10$Kk/.JksZLJm5CvRK05g4h..A9Bk6T0eJvmSjwBG7BPM3DfVs3BSxG',
    'test',
    'user',
    '5739d5b7-a80a-4b5b-8cdc-e9bdff9776cf',
    NULL,
    'Category',
    1,
    1,
    NULL,
    '2025-11-03 22:56:12',
    '2025-11-03 22:56:12',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '0d6b1083-54be-4b89-beaf-5a6cff925ef8',
    'jane.wanjiku@turnkeyafrica.com',
    '$2a$10$bZLdjqCBj0j43xOZzHPsz.MCcpUdnSOfA5mYyQiJ821rpa5iluDf6',
    'Jane Wanjikuu',
    'user',
    '518edc29-908a-4f4b-9f58-2fc580f62e69',
    '+254-700-000-002',
    'HR Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-31 22:23:56',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '0df2a894-c56b-4be7-a9d7-7ac8e5abb602',
    'breda.kathuri@turnkeyafrica.com',
    '$2a$10$5.jV.ILsekUYzOSAO.hhceh9G.WWG9JzZ5wgtENN6ghUuuXpqBdbm',
    'Breda Kathuri',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:39',
    '2025-09-07 21:47:39',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '0f8d01ea-a4ee-11f0-a26e-08f1ea8e398e',
    'beldine.oluoch@turnkeyafrica.com',
    '$2a$10$a4qCK.GM1S528C89.MsdneJ1hasx/pFQCba4havyK.deBqkvTyNei',
    'Beldine Oluoch',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0799946480',
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 01:58:00',
    '2025-10-09 01:58:00',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '12022181-7e81-420a-9819-ad6e109ad28f',
    'lisa.nyambura@turnkeyafrica.com',
    '$2a$10$MJZ2aUIkVjG9cSdLgsfQ7.LavVjSkA6j4wjI2VtJ4IhOMgeyhCrs2',
    'Lisa Nyambura',
    'manager',
    NULL,
    '+254-700-000-006',
    'Sales Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:11',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '14043440-4ce8-45f9-82ac-da8992c0ada7',
    'habiba.halkano@turnkeyafrica.com',
    '$2a$10$B9f0tGkjEJY2zTLm.Q4l5u4QKwjVsFEZrk3WW2sv5cuHLthFzgzte',
    'Habiba Halkano',
    'user',
    NULL,
    NULL,
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-09-23 03:09:52',
    '2025-09-30 05:56:34',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '1415bf33-abd3-4a55-9d8a-55321592f97e',
    'james.chuma@turnkeyafrica.com',
    '$2a$10$bb181.c5d.HxuE6pezy8tuVPvGpWcoFSMk.afaQnrQkEFdyJEsFJG',
    'James Chuma',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:06',
    '2025-09-07 21:48:06',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '15a3d503-5139-4a68-849f-e9b324cf174c',
    'sydney.boruett@turnkeyafrica.com',
    '$2a$10$m.GwMRvtcQjpMh/XCX3SvOXm0MnOthrj7SCUIVjmKKPgru9Q/rUJq',
    'Sydney Boruet',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:31',
    '2025-09-07 21:48:31',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '175b5b6e-2ca7-4f93-bb05-e3a5fe947f61',
    'hagerty.cars@gmail.com',
    '$2a$10$cp3FlKUhkWEqSEgJVFWJgecsYB.dnC.vZbaFstXkIT2wss1tC.3yG',
    'test3',
    'user',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    'CoE Manager',
    1,
    1,
    NULL,
    '2025-11-04 00:29:33',
    '2025-11-04 00:29:33',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '1b4b5a01-6245-455d-b2c7-19fdcf85ce36',
    'warlys.aduvaga@caavagroup.com',
    '$2a$10$6TxGx/MuMR0hM.uo8GTSdelxj3V/y/DillbjQqWa8brnw0j8nvnPm',
    'Warlys Aduvaga',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:34',
    '2025-09-07 21:48:34',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '1d73d444-3672-4e11-8cd3-7eacb71de9e4',
    'mbugua.samuel@turnkeyafrica.com',
    '$2a$10$1/q7uOu/onaFy2/SKOZ0DeM2YifXx0Jg3z5RJL7xRDrG/7jelQA46',
    'mbugua samuel',
    'user',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '',
    'Team Lead System Engineer',
    1,
    1,
    '2025-10-09 05:05:24',
    '2025-09-07 21:48:16',
    '2025-10-17 07:16:03',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '1de1decd-f518-4fa7-bf84-964d6288ed55',
    'linabel.adhiambo@turnkeyafrica.com',
    '$2a$10$xYeiFeL/B0OjLvo.L37KZufLOdkumvj0b3kEH5vc90U.O75Kt1J1.',
    'Linabel Adhiambo',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:14',
    '2025-09-13 10:16:37',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '1dee8612-b028-4b24-b165-ac3c40c1c076',
    'douglas.motito@turnkeyafrica.com',
    '$2a$10$0N.rxC03AaDma0TvbWxu8e26gebQPKuVB2BDLQWM3gQjTS/OkNYJ.',
    'Douglas Motito',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:50',
    '2025-09-07 21:47:50',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '1e514bc5-a51e-11f0-a26e-08f1ea8e398e',
    'gabriel.mbaiorga@turnkeyafrica.com',
    '$2a$10$NnVMgtNDjQ7xdOuqM5M18.XlSpnd4gHITl6J3c9OT.vfweHZ3cf8q',
    'Gabriel Mbaiorga',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0117524970',
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 07:42:01',
    '2025-10-09 07:42:01',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '1eb9e711-33c3-493b-bcdb-a3cfcd4a77cd',
    'david.mutua@turnkeyafrica.com',
    '$2a$10$W/4rozlHDg93PIROg2YQHO8Rctqdh0IhvyV7icyydxTv4la8jzKHq',
    'David Mutua',
    'manager',
    '0f494aa6-a2e8-49c9-a522-36ef7dfe225a',
    '+254-700-000-005',
    'Marketing Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:09',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '20ab87f2-7d3d-479e-84a7-63a6309ad7fe',
    'mary.wanjiru@agencify.insure',
    '$2a$10$R/ab9n/duYKV1V1iBrbNIuZEmMIYcZZwX7BG.cPIvDcj2eQyo1zqi',
    'Mary Wanjiru Njue',
    'user',
    '61117f75-30c0-4d57-8e48-5a198ed9ef72',
    '0745994294',
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-09-22 00:02:00',
    '2025-09-22 01:48:01',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '21dcf672-a522-11f0-a26e-08f1ea8e398e',
    'samuel@turnkeyafrica.com',
    '$2a$10$RtD2J7c/Jq/IghYM2bXvBePWULGysvZe/XJ11nTRDFGGz9lzjxtzi',
    'Samuel Nyong\'a',
    'user',
    '48bce373-a521-11f0-a26e-08f1ea8e398e',
    '254726980456',
    'System Architect',
    1,
    1,
    NULL,
    '2025-10-09 08:10:45',
    '2025-10-09 08:10:45',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '22bca7b2-9f2e-4eee-a9f0-747cfd056c3f',
    'david.ogubi@turnkeyafrica.com',
    '$2a$10$lrgJCEAnQ0osU6i7DzE5YeCbD8N53JIGrux4V70JPwGBkVjfhbALu',
    'David Ogubi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:47',
    '2025-09-07 21:47:47',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '2686f810-ef45-420d-978d-549e62d98ff5',
    'evance.onyango@turnkeyafrica.com',
    '$2a$10$dahZwz5wy8.cHEclHUVBluiNjng3cVKE8xaLJ/DVn4QhK5G/A8iYO',
    'Evance Onyango',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:30',
    '2025-09-07 21:47:30',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '28acdbf4-5ec2-4e2b-9d33-312b6c7e3fd9',
    'tom.thuku@turnkeyafrica.com',
    '$2a$10$lvkFxEIr8jryYkZgbG1oXeV1ckH17Dn74CZ0/K9Sj8/2xE1OtkH26',
    'Tom Thuku',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:32',
    '2025-09-07 21:48:32',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '28ed85f8-03bc-4f03-bdc2-235ce282cf3c',
    'sharon.nasiombe@caavagroup.com',
    '$2a$10$xWxv4KH/2RQMn/KLtsjOFeYmbEHiEM1Xly/I7SKb/GjKLeotbnAra',
    'Sharon Nasiombe',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:27',
    '2025-09-07 21:48:27',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '298eda2d-a523-11f0-a26e-08f1ea8e398e',
    'hiram.mugambi@turnkeyafrica.com',
    '$2a$10$q6u5fn7Ui34WSaeERSwsi.u78RlMWAidYh6sfMdzchRdaBPdIIQS.',
    'Hiram Mugambi',
    'user',
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    '',
    'Software Engineer',
    1,
    1,
    '2025-10-26 03:07:45',
    '2025-10-09 08:18:07',
    '2025-10-26 03:07:45',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    1
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '29bad42f-a524-11f0-a26e-08f1ea8e398e',
    'emmanuel.kipkorir@turnkeyafrica.com',
    '$2a$10$.jHkOZQ6m3M977FXx.nsBu4V43KvcRjpep.6B7HdnfsaqUr9Gnwby',
    'Emmanuel Kirui',
    'user',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    'System Engineer',
    1,
    1,
    NULL,
    '2025-10-09 08:25:17',
    '2025-10-09 08:25:17',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '2a269cdf-f02a-4f6f-a696-ea8edf983291',
    'hannington.omondi@turnkeyafrica.com',
    '$2a$10$Sq0tWl/Gbe92UZXL0MbzBOm4ijapeTsCZCTyhRmVfpxxrVzNcQYpy',
    'Hannington Omondi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:02',
    '2025-09-07 21:48:02',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '2d1d4644-36a4-4cea-83bb-62106f58361f',
    'jecinta.mbiti@turnkeyafrica.com',
    '$2a$10$c6RqcNUjXaG9.h1/a5i7zuLXV2971edOHrIUFyj9G8cRJyT29I87W',
    'Jecinta mbiti',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:08',
    '2025-09-07 21:48:08',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '2f5d5c1b-ba09-4259-a02c-748234fa6f67',
    'michael.otieno@turnkeyafrica.com',
    '$2a$10$8Y7jNpKswxj/6M8lx1gC0e1lw6RrfvYC.EjdTuqKRQ22jQN9NkcWG',
    'Michael Otieno',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:18',
    '2025-09-07 21:48:18',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '2fc7c86f-f14a-4c86-b0e1-52d36f546b82',
    'daniel.wanina@turnkeyafrica.com',
    '$2a$10$aRSE4CsM.2cP3OKb3NOmtOrSx8FwU/.Asym64oAMFntMXYSR9PW52',
    'Daniel Wanina',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:46',
    '2025-09-07 21:47:46',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '2fdcc906-dde1-4f26-8269-d66df66dd7eb',
    'alex.kipchirchir@turnkeyafrica.com',
    '$2a$10$uTauOD9dloGfeSCaF17KJeMReX4laJvyo47RmPd4Op0jzK9J0tXWS',
    'Alex Kipchirchir',
    'user',
    NULL,
    '+254-700-000-009',
    'Software Developer',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:15',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '3889eb7e-a51f-11f0-a26e-08f1ea8e398e',
    'skaruga@turnkeyafrica.com',
    '$2a$10$GHWam1s1gg0kME7aDOT8jurJBvsT8dRnruAxwhU4AeXvP7L2.q.hy',
    'Sam Karuga',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0721435257',
    'Software Engineer',
    1,
    1,
    '2025-10-09 23:52:35',
    '2025-10-09 07:49:55',
    '2025-10-09 23:52:35',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '3d22f398-390a-48d1-b875-51db099b5640',
    'irene.mutheu@turnkeyafrica.com',
    '$2a$10$yQBjjdYpAlZgXGounGhY9OCcUiHCsf9gO0UUF.7LPiwjodgnZ24Ri',
    'Irene Mutheu',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:04',
    '2025-09-07 21:48:04',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '3ec64e91-62f4-4419-8856-844335030ff1',
    'cecilia.wanjiru@caavagroup.com',
    '$2a$10$ZrYMlBH4ydUV4veABJXm6ebXvmlwmALDJSxh8QU2G.onxrCJ/e6Oq',
    'Cecilia Wanjiru',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:42',
    '2025-09-07 21:47:42',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '4090ba40-4047-4e94-8ce8-0c383b7c34ca',
    'cynthia.mburu@turnkeyafrica.com',
    '$2a$10$422UZD4pYv22LX1Xfk2RW.003kyR8kUJsjV6zpcaxWp42C/GnUJx2',
    'Cynthia Mburu',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:44',
    '2025-09-07 21:47:44',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '40a62d59-b35e-406a-a0f9-2ff1cfefb5bc',
    'kimkahunja@turnkeyafrica.com',
    '$2a$10$FB.tBACXsN0bm46O7Yalxuxwxig2Irf2Kxv5P/aiWqmmf4/H6K.8K',
    'Kimotho Kahunja',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:13',
    '2025-09-07 21:48:13',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '41c461c5-7494-4bb3-a028-ad829c707022',
    'justus.obisa@turnkeyafrica.com',
    '$2a$10$5AjaQAliKgL2G5AZruYIT.Cl4mmgLHvGx7W/75kIBgEnwWP31Xhii',
    'JUSTUS OBISA',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:11',
    '2025-09-07 21:48:11',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '4273684a-89bf-4d96-bdb1-5c06a172b9a4',
    'penorah.buyaki@turnkeyafrica.com',
    '$2a$10$eWw24G8AT3YhB7Thl9/St.0rL6DIYLJcdfK3nfgiAh8Cqgt.Sk50O',
    'Penorah Buyaki',
    'user',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    NULL,
    'PSM Manager',
    1,
    1,
    '2025-11-03 05:43:57',
    '2025-10-28 00:34:46',
    '2025-11-03 05:43:57',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    1
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '45db02ef-a523-11f0-a26e-08f1ea8e398e',
    'sixtus.acha@turnkeyafrica.com',
    '$2a$10$lruFaCno1XbkeQliN4/rGOFWOnkNeDnneGtPPyip7cQiUOyWnJMcG',
    'Sixtus Acha',
    'user',
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    NULL,
    'Software Engineer',
    1,
    1,
    '2025-10-09 09:22:50',
    '2025-10-09 08:18:55',
    '2025-10-09 09:22:50',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '4701e2a6-676b-475d-b053-322589e6384e',
    'mercy.mateelong@turnkeyafrica.com',
    '$2a$10$UCTUbadI10NUajh9DWyIZekNuxE/GeFbMgEzHM8rUg/jmQ.dxW6jG',
    'MERCY MATEELONG',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:17',
    '2025-09-07 21:48:17',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '4871a7ef-e390-46cc-ab5c-1989dfeab564',
    'kenneth.chepkwony@turnkeyafrica.com',
    '$2a$10$sKQFAIa.2sLF/IS2S08SHuDYoDjZug3Vuag2PMaKC1TzG7QEwODFG',
    'Kenneth Chepkwony',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:12',
    '2025-09-07 21:48:12',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '48a002a8-a520-11f0-a26e-08f1ea8e398e',
    'philip@turnkeyafrica.com',
    '$2a$10$6HUA0ykiGB1qC1aVb8eLGufrWfy9Q7glG3A22OI9cfGoJa1JpgZem',
    'Philip',
    'manager',
    'ebccace8-a51f-11f0-a26e-08f1ea8e398e',
    '0703988055',
    'Software Engineer',
    1,
    1,
    '2025-10-14 13:45:12',
    '2025-10-09 07:57:31',
    '2025-10-14 13:45:12',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '4c76e663-593d-477c-b90f-5b026a560f80',
    'titus.bundi@agencify.insure',
    '$2a$10$Ftq4vmzXDzYBiVe1rhbA2.3PZnyyeOaUkeOWkc2HoobBqqhYGP9ue',
    'Titus Bundi',
    'user',
    'c6b07ab2-b175-4a74-a3f9-2afeac9b52b7',
    '0795307426',
    'Software Engineer',
    1,
    1,
    '2025-10-30 01:26:28',
    '2025-09-22 01:25:17',
    '2025-10-30 01:26:28',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '4f93b92a-03c7-49fb-a601-cd07ed50fdde',
    'sharleen.mochama@turnkeyafrica.com',
    '$2a$10$m51Bhf3yIWoQPWWjxXJZE.UFS3Nw.iSgBvTEQaIfjo5ZstItMZRwC',
    'Sharleen Mochama',
    'user',
    'f0207ab0-de7d-466d-978a-bc84473e1c49',
    NULL,
    'PSM Manager',
    1,
    1,
    '2025-10-27 03:28:22',
    '2025-10-27 01:30:54',
    '2025-10-27 03:32:07',
    1,
    0,
    '2025-10-27 01:58:14',
    '2025-10-27 03:31:23',
    0,
    NULL,
    1
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '55ab395a-88a7-4310-9af3-0ca6ecb1ae93',
    'kipkoech.donald@turnkeyafrica.com',
    '$2a$10$NiA9OHkA8rG0qa0FVoo5vuiuj6fc4YGfrQREDl/lX/sR1eqRU87pG',
    'Donald Kipkoech',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:30',
    '2025-09-07 21:47:30',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '56a3715b-3116-4f6c-90bd-477cbef8b9a7',
    'fiona.mokua@turnkeyafrica.com',
    '$2a$10$SfKmZbjAFIul..Lzp99xjehtwww4fwPP0j6Wu1oqT8tOM7pQFaTnS',
    'Fiona Mokua',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:59',
    '2025-09-07 21:47:59',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '5a485d0b-2c13-492c-b526-08bbbd6f6ca7',
    'carren.chepkorir@turnkeyafrica.com',
    '$2a$10$zzpqQUmOK0vReW0x3A2lP.mqGyEuGsKxTVlBF0kcgHSjHbxZfPH/q',
    'Carren Chepkorir',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:42',
    '2025-09-07 21:47:42',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '5be5170a-b975-4746-852a-01ba45d20b83',
    'jael.abuga@caavagroup.com',
    '$2a$10$1BFDuGodATuFQb0R3ocREedQmbvDQEnFuuiFYoh2ZUXAFN1vLwuw2',
    'Jael Abuga',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:05',
    '2025-09-07 21:48:05',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '5c041465-6176-4770-b63c-01c1a2b1d1d1',
    'robinson.githae@turnkeyafrica.com',
    '$2a$10$cTsKGDS/s5DfCwiEy2jzZ.HAk.jApJiA1hh.k7liFZhnbq1WwfyNq',
    'Robinson Githae',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:24',
    '2025-09-07 21:48:24',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '5d015f24-a0e9-4a4a-9149-025d7abc57da',
    'anastasha.chemutai@turnkeyafrica.com',
    '$2a$10$4AUMbCHPY18Tq30sWT/KCOYubu8PaMbsNXDhQtoJFlKQ8CSQl5552',
    'Anastasha Chemutai',
    'user',
    'fdbba582-e020-4905-b56d-bf7beaa5b6d0',
    NULL,
    'Unknown',
    1,
    1,
    NULL,
    '2025-09-07 21:36:26',
    '2025-09-07 21:36:26',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '5f579be7-91bc-4555-bcc9-98a14fa3ef1e',
    'patrick.kipngeno@turnkeyafrica.com',
    '$2a$10$9jZpD4v2rnxyw1xD3EqoPO.BawfoYXBUQNGu73qqFEYJvbepdmkM6',
    'Patrick Kipngeno',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:20',
    '2025-09-07 21:48:20',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '5f6d2d5b-03c8-449f-b1d9-da2e80f2e85a',
    'isaac.mburu@turnkeyafrica.com',
    '$2a$10$abSZkg/LjIYvAUJCeAshiul.bpn/MKxyAgpF0JIK0ypawTpn5hkJW',
    'Isaac Mburu',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:04',
    '2025-09-07 21:48:04',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '6286cdc4-a51e-11f0-a26e-08f1ea8e398e',
    'farida.nambua@turnkeyafrica.com',
    '$2a$10$8wdBJyyXrRp9kR9sAivAue03YC6Q3lJWJ9z3ozrRzfVZZVO7fLfH.',
    'Farida Nambua',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0769164326',
    'Intern-Engineering',
    1,
    1,
    '2025-10-09 23:24:27',
    '2025-10-09 07:43:56',
    '2025-10-09 23:26:16',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '637f4b7b-4e7f-4928-933f-b71ccb8e417c',
    'alfaxad.ogesa@turnkeyafrica.com',
    '$2a$10$8AkynMfh0PPziIRKR7SPKOd8Rvn8QKQGn.URmPXUwadzAa4Zid6AC',
    'Alfaxad Ogesa',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:33',
    '2025-09-07 21:47:33',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '63ec8458-a4ee-11f0-a26e-08f1ea8e398e',
    'felix.mukabana@turnkeyafrica.com',
    '$2a$10$TrYgAVKr8tXeL0XTThfWwOMFFrpM6ddsHwFnwefBETjcqdJbhxeoe',
    'Felix Mukabana',
    'user',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    NULL,
    'Entry Level 1',
    1,
    1,
    '2025-10-31 10:36:41',
    '2025-10-09 02:00:22',
    '2025-10-31 10:36:41',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '643be7ce-4af3-410c-a8f7-0ebfe720d153',
    'mike.kamau@turnkeyafrica.com',
    '$2a$10$EqYS.8avjMNFUTE76DdkvehOWDebTZieROrMzpG6dH1m.Z0n6jSbC',
    'Mike Kamau',
    'manager',
    '518edc29-908a-4f4b-9f58-2fc580f62e69',
    '+254-700-000-003',
    'Finance Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:22',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '64eacb63-2253-4884-9414-9bbd6d0e98e3',
    'hannah.waceke@turnkeyafrica.com',
    '$2a$10$bXPutGlo.ZuavI.FJiEAWOMOJ9FjBDE9n2x0EfSaLSAsvoMeYwVSO',
    'Hannah Waceke',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:01',
    '2025-09-07 21:48:01',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '662cf4d7-dbbd-4371-8114-63b20c1208a8',
    'hope.ibrahim@turnkeyafrica.com',
    '$2a$10$H1fPM4HXE9Zn2300FhQsy.7QzrhbXX9Pciv5dQ9PI7VErThc9xPvS',
    'Hope Ibrahim',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:03',
    '2025-09-07 21:48:03',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '6b3c2855-da49-45fc-bc76-60feac2fdd6a',
    'maria.wanjiru@turnkeyafrica.com',
    '$2a$10$HfVBn/uqXrbwvzeudK1XMOMNr3DcQ5TjmdVLSn4/2sSdKj4fW8X1G',
    'Maria Wanjiru',
    'user',
    '518edc29-908a-4f4b-9f58-2fc580f62e69',
    '+254-700-000-010',
    'HR Specialist',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:16',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '6bec2d3a-0349-4e34-a3f8-e8380fe921b8',
    'monicah.nyakundi@turnkeyafrica.com',
    '$2a$10$YBSfxQ5fN7A8pZpOEvi.2O53qgs0ioUMfNXlLkpNElg0sd4UoslrW',
    'Monicah Nyakundi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:19',
    '2025-09-07 21:48:19',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '6ea787f9-9258-4924-b17f-30ee86cbd2cc',
    'jackline.njoroge@turnkeyafrica.com',
    '$2a$10$FCKgAwSaq0oD/xKYgAIUWucjldGGH5znTzimmMhOwQa3syuR51Tcq',
    'Jackline Njoroge',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:05',
    '2025-09-07 21:48:05',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '6f651afd-8238-4838-9c90-2c75bbd5d466',
    'joanes.mieni@turnkeyafrica.com',
    '$2a$10$7j7YKIAsOd5GJr0DY5Q8becKIJA0gxLZdvLOZlzsVK6f7IMqQtpRG',
    'Joanes Mieni',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:09',
    '2025-09-07 21:48:09',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '6fa37ca7-7fca-4f2d-9152-038c058d31cc',
    'william.maina@turnkeyafrica.com',
    '$2a$10$CLp6yAME9xEhwskCJBD.xecaMfzW/hXh96PCibQfpTu9t7NDj26XO',
    'William Maina',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:34',
    '2025-09-07 21:48:34',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '6fdeb76e-456a-406f-92c9-e4459bd7e936',
    'james.kimani@turnkeyafrica.com',
    '$2a$10$DIfKl3UWujNSdVUhHHuxmOjL5sUu7HLTYF/9GFrePoMORx1ULTPP2',
    'James Kimani',
    'user',
    'aa8e955f-69c6-40d1-9a35-54948620bc9a',
    '+254-700-000-011',
    'Accountant',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-31 22:23:26',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '721a6ac2-7282-481c-8a21-9aba6e8fa68a',
    'frankline.nthamburi@turnkeyafrica.com',
    '$2a$10$NOfnPT6OX2xzDOpvaVZaKO34hYAIvwOLvBIuxKOoZedluB5iu85J6',
    'Frankline Nthamburi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:59',
    '2025-09-07 21:47:59',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '77a16360-f094-4fe2-bfb3-8118b4997fc8',
    'velma.gatwiri@turnkeyafrica.com',
    '$2a$10$DTQ3aWl7ESj/wXiQaLyLKO/ObxwEBZiC.cXeM7TPbp3Ike7hqHxGW',
    'Velma Gatwiri',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:32',
    '2025-09-07 21:48:32',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '7953f873-aeb1-44bf-9155-4699b7e44c31',
    'sylvia.achieng@turnkeyafrica.com',
    '$2a$10$fFYRHycyZ/c8NLmWx7nbTuK/NJV.BMGAp7Fe0qad0J9gO1KHYr8da',
    'Sylvia Achieng',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:31',
    '2025-09-07 21:48:31',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '7a0adfcc-7c88-4e8b-a99b-ff89a0ae93d3',
    'lorraine.bwayo@turnkeyafrica.com',
    '$2a$10$1SQ1HcEEKwg3oBXG.edpkeamcQDz5dcQuwTRzgudoTcZN0SCXuWW.',
    'Lorraine Bwayo',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:31',
    '2025-09-07 21:47:31',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '7ba540e1-a521-11f0-a26e-08f1ea8e398e',
    'kenneth.korir@turnkeyafrica.com',
    '$2a$10$jkTJLNoYfKOVcJ86g9MfSOk2UoTlvjx45mMEG6LpNadbfxvJMnOJa',
    'Kenneth Korir',
    'manager',
    '48bce373-a521-11f0-a26e-08f1ea8e398e',
    '0717287999 ',
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 08:06:06',
    '2025-10-09 08:11:12',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '7c0aab87-29d5-4c9b-926c-dd5ec67dc6c8',
    'dancan.wanyonyi@turnkeyafrica.com',
    '$2a$10$T7mLz//IGs1KpgQBmOZSbexpngIV8BbSaa.ZCS15IBBC.m0rGHDP.',
    'Dancan Wanyonyi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:46',
    '2025-09-07 21:47:46',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '7d40ad44-4e03-46e1-b7fb-4f3ed5b282bc',
    'mary@turnkeyafrica.com',
    '$2a$10$.gCnppUrKYdJMJDiP8ogfuz1IZGvnbtgE3CCsayeJfrKWXfxyFp4u',
    'Mary Kamau',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:16',
    '2025-09-07 21:48:16',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '7e868e17-bd17-46d8-9666-7b1fffbd9966',
    'leon.maina@agencify.insure',
    '$2a$10$.TpQwgogPjrG7WgDuSFlPenWWWbvxZ28tiN0/nz2V5q0IMlj9V5CK',
    'Leon Maina',
    'manager',
    '249993e1-7e0d-4d1d-8e92-cad9ca730a37',
    '0720107257',
    'Business Analyst',
    1,
    1,
    NULL,
    '2025-09-22 02:12:17',
    '2025-10-29 00:35:54',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '80ed7c80-a88c-4438-8c5e-e85998829795',
    'clinton.shikuku@turnkeyafrica.com',
    '$2a$10$twKe.VMxRaatCFbhEjV2iuKUnzyVN8xNzdyJ4VqLZX1Z5kGZ7zKzm',
    'Clinton Shikuku',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:44',
    '2025-09-07 21:47:44',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '8172634d-a520-11f0-a26e-08f1ea8e398e',
    'jonathan.onderi@turnkeyafrica.com',
    '$2a$10$Yjt6E.p0giB1UuY8u46CLO9YK3t7ukwauqTdFPDpPtWyen6IK0X2e',
    'Jonathan',
    'user',
    'ebccace8-a51f-11f0-a26e-08f1ea8e398e',
    NULL,
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 07:59:06',
    '2025-10-09 07:59:06',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '81bebaae-d4b6-4b13-9794-1b09e16fd286',
    'duncanmiheso@caavagroup.com',
    '$2a$10$M9G5nJuopimcd.Cw88PV1u9Ct.HmZo3gkL119aYGrTh.jqEkTVrhW',
    'Duncan miheso',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:51',
    '2025-09-07 21:47:51',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '8493617c-1bff-4d64-b374-6a3514cfcd10',
    'philip.ikambili@agencify.insure',
    '$2a$10$xk2xITsefYECJSIHIZdL4uoWfsgNOgMnRaAqGOJCNUgji5gjwm4kC',
    'Ikambili Philip Kwimba',
    'user',
    '61117f75-30c0-4d57-8e48-5a198ed9ef72',
    '0708803209',
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-09-22 00:04:35',
    '2025-09-22 01:47:44',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '86116fd2-a524-11f0-a26e-08f1ea8e398e',
    'eugene.lumala@turnkeyafrica.com',
    '$2a$10$t.serbO9gbIB00jHtilJF.BrGVxsm8O1wg0KBIN0W4sbxXW9CfG/a',
    'Eugene Lumala',
    'manager',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    '',
    'Team Lead System Engineer',
    1,
    1,
    '2025-10-09 08:29:10',
    '2025-10-09 08:27:52',
    '2025-10-27 05:44:55',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '8805038b-9df8-4ae1-bba1-2a7ff50f13b0',
    'patience.kariuki@turnkeyafrica.com',
    '$2a$12$DRdXcIEgj7/QYxGtERbgmewQpBQEiegBtKuJjOTffOeJwdkl9rw42',
    'Patience Kariuki',
    'user',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '0706950911',
    'Business Analyst',
    1,
    1,
    '2025-09-30 02:06:12',
    '2025-09-24 02:39:44',
    '2025-09-30 05:56:34',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '8f34025e-afeb-44b0-b6a0-4226e742dd29',
    'antony.nderitu@turnkeyafrica.com',
    '$2a$10$E5tczefRwKLKp9IKbOD7q.2E2/g6N69m/s7oQTw8Hjo.jrJ3ulJCC',
    'Antony Nderitu',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:36',
    '2025-09-07 21:47:36',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '93ddd6ca-406a-41a4-be5f-7f5cbe745b8d',
    'amos.kiarie@turnkeyafrica.com',
    '$2a$10$bWG3FCsA4kbFTum3LCmUP.vJQhjGkXj2OkY1Aq98kIeORVo4ZeNyG',
    'Amos Kiarie',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:34',
    '2025-09-07 21:47:34',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '94e5c176-9496-48f9-9a64-e54fbb9006e1',
    'fred.kariuki@turnkeyafrica.com',
    '$2a$10$42KaDinkp3tLtC3p1I9UZ.1CD7ecVAhit6vRV4s4Th9Zv73hO0baq',
    'Fred Kariuki',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:00',
    '2025-09-07 21:48:00',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '96ff44d5-0d98-4fe6-820b-af94d5395891',
    'edwin.madeda@agencify.insure',
    '$2a$10$VVpzTVtzfvABsXCJtfsIo.qOusWuy.ouAdioUr4qj68iQevSOjxpm',
    'edwin',
    'user',
    '61117f75-30c0-4d57-8e48-5a198ed9ef72',
    '0706304505',
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-09-21 23:55:07',
    '2025-09-22 01:48:16',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '9aa48523-2ee8-43af-a198-9b9ec0a2aeff',
    'edmund.nyaribo@agencify.insure',
    '$2a$10$.v3TgO.iKp.bD8WBki0A0uN.06jqozxevBkcPD.J3m.jCWOz8H.8i',
    'Edmund Nyaribo',
    'user',
    'c6b07ab2-b175-4a74-a3f9-2afeac9b52b7',
    '0793507069',
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-09-22 00:14:18',
    '2025-10-29 01:00:26',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '9b7f4c02-7323-410f-aa50-741cc7df9176',
    'james.bahati@turnkeyafrica.com',
    '$2a$10$2pWPjJGlvAQ8YdOlmvQ3ZuRRgsWmjFVYSikmgH5SW6C.G2sWDx4B.',
    'James Bahati',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:06',
    '2025-09-07 21:48:06',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '9ba2ece3-a51e-11f0-a26e-08f1ea8e398e',
    'collins.chacha@turnkeyafrica.com',
    '$2a$10$yBMb/Ycp24u/SG/UGA5l3Oq5Ciy7ilTd061exhcD6YLZeh/WQ6Jcq',
    'Collins Chacha',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0706213920',
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-10-09 07:45:31',
    '2025-10-09 07:51:00',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '9e88c79c-aa5a-4e82-a471-92bc075f6575',
    'samuel.mbugua@turnkeyafrica.com',
    '$2a$10$ySfcLixh/Id3ujnQIECQHelAbI3jdD4c.ttRsKXIPRR9/L1IJV9bK',
    'Samuel Mbugua',
    'user',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '',
    'Team Lead System Engineer',
    1,
    1,
    NULL,
    '2025-09-07 21:48:26',
    '2025-10-17 07:15:43',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '9fb347b2-8a60-48c0-92f9-f6e03425b374',
    'cinthia.mudiri@turnkeyafrica.com',
    '$2a$10$c6nTieXiDqzJCAH.wOwVcunowN.c4FANXgNKZ6JBRoVDpTML7tLSW',
    'Cinthia Mudiri',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:43',
    '2025-09-07 21:47:43',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    '9fd2b57e-5a45-489a-9b0f-56bc62a7317f',
    'emily.chebet@turnkeyafrica.com',
    '$2a$10$TWC6pfP9eY/EbeTfcSeT4eAt4zWsidjF7upybN0V5ayeGyYHT7LkW',
    'Emily Chebett',
    'manager',
    NULL,
    '+254-700-000-008',
    'Support Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-25 01:58:20',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'a5bafa73-b304-4d31-934c-09f8019eac22',
    'rigan.gor@caavagroup.com',
    '$2a$10$cesiFCD8cyuubnQwuWAA4OKBS6hWN8TWtjM1ALdCl7Pq/IBHzbCrW',
    'Rigan Gor',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:24',
    '2025-09-07 21:48:24',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'a73544e3-a51d-11f0-a26e-08f1ea8e398e',
    'martin.nganga@turnkeyafrica.com',
    '$2a$10$N60FPJTcSLPsA1HwUmXPiet5izPHgLpK3MPQSjOz35kgJsvQGQBce',
    'Martin Nganga',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0713592581',
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 07:38:41',
    '2025-10-09 07:38:41',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'a751e209-a522-11f0-a26e-08f1ea8e398e',
    'emmanuel.rabongo@turnkeyafrica.com',
    '$2a$10$mqMeDIXOBlhny5qkE0mH..tEWEuxjx8E0FB6dNMeqQ.ASRMiWCPHm',
    'Emmanuel Rabongo',
    'manager',
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    NULL,
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 08:14:29',
    '2025-10-09 08:28:31',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'a97ed2c7-d0e8-4bae-bf24-3b894c63fd8c',
    'brian.muriithi@caavagroup.com',
    '$2a$10$8r.HE5GG63krTDgsG7nGju4UsR5NYw0Twx5IfiDtl4kIJF.AfA3Bi',
    'Brian Muriithi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:40',
    '2025-09-07 21:47:40',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'a9e91e57-6912-4f44-bcbb-9f8d68043eb4',
    'shiyayo@turnkeyafrica.com',
    '$2a$10$ExSfMZKqW1nyQV.l.wQhqOAcf9pXdqlIP63BiTJc82oX6jtckHJu2',
    'Shiyayo Cathy',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:29',
    '2025-09-07 21:48:29',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'ab4c871e-a520-11f0-a26e-08f1ea8e398e',
    'john.gachoki@turnkeyafrica.com',
    '$2a$10$M0LGBsDOepZA5OSrj.ffIO1CmbOWtgTM3fl8ohR20Vh/LezJGsy/y',
    'John Gachoki',
    'user',
    'ebccace8-a51f-11f0-a26e-08f1ea8e398e',
    NULL,
    'Software Engineer',
    1,
    1,
    '2025-10-12 23:26:20',
    '2025-10-09 08:00:17',
    '2025-10-12 23:26:20',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'ad584988-a9c4-4228-9724-4cdb3bdfbc1e',
    'sophia.muthoni@turnkeyafrica.com',
    '$2a$10$dLjChe0y2h4XNmH3iXGDpe9RojmcJKAYSAWnD3AoTS503lSRPMijS',
    'Sophia Muthoni',
    'user',
    '6901b725-fd67-4d9f-9c03-9b3cee064e84',
    '+254-700-000-012',
    'Operations Analyst',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:19',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'admin-user-id',
    'admin@turnkeyafrica.com',
    '$2a$10$23hG3fJUIalwskDwlCrPBObhueoORjk2Y9Rn4dJIYB3.fIkoZ.P3G',
    'IT-Team',
    'admin',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '+254-700-000-000',
    'CEO',
    1,
    1,
    '2025-11-04 00:49:44',
    '2025-09-28 12:45:24',
    '2025-11-04 00:50:54',
    1,
    1,
    '2025-10-19 04:41:19',
    '2025-11-04 00:50:54',
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'ae824ad3-1358-403f-9c7e-5579ba55b84e',
    'stephanie.oyalo@caavagroup.com',
    '$2a$10$U9mw.Obp32dPwEQ0CrGwwud9q6asybj7pzYRw7zVTc3OefBUFVxdi',
    'Stephanie Oyalo',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:30',
    '2025-09-07 21:48:30',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'b3a13df1-9343-43c3-bc0e-aa0db50fbe99',
    'mary.njeri@agencify.insure',
    '$2a$10$lMNJDpwtbeeei4kVSpx7.uQR1IWM1/hNPsKLUUMKjgRlCKDQEGHHS',
    'Mary Njeri Ngugi',
    'user',
    '249993e1-7e0d-4d1d-8e92-cad9ca730a37',
    '0706792878',
    'Business Analyst Intern',
    1,
    1,
    NULL,
    '2025-09-22 02:26:24',
    '2025-10-29 00:26:09',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'b3c89369-8678-4984-811f-1042c2e7b6c2',
    'faith.mugo@turnkeyafrica.com',
    '$2a$10$A8TMVL/aY8HQY1R3QiG1suH58KM53Nd/ji8MUbUf9fLtNOwE/yaq2',
    'Faith Mugo -',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:57',
    '2025-09-07 21:47:57',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'b5443f03-f09b-445a-923b-4e688ada735b',
    'raquel.odhiambo@caavagroup.com',
    '$2a$10$iVPu1oKq2e5j4OgAKzY1Ze6yiUD71U2bNjhpJ305liciMC0NpyElW',
    'Raquel Odhiambo',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:23',
    '2025-09-07 21:48:23',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'b5ac3a64-a521-11f0-a26e-08f1ea8e398e',
    'cephas.osei@turkeyafrica.com',
    '$2a$10$6VDDaQtjFQtUfJWBKaW9lup5n6XaBj073RiWPde78hf0VQxBbEBBe',
    'Cephas Osei',
    'user',
    '48bce373-a521-11f0-a26e-08f1ea8e398e',
    '233207308301',
    'Senior Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 08:07:44',
    '2025-10-09 08:07:44',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'b6d63cfa-f2d1-4e55-85f2-57d76e8a46a0',
    'susan.neema@agencify.insure',
    '$2a$10$muZSYJ8sqU84/3uHocy9HeUhZGRlJpoRIJn.bGjQZy73kPQ0/uLuu',
    'Susan Neema',
    'user',
    NULL,
    '0703636494',
    'Intern-Support',
    1,
    1,
    NULL,
    '2025-09-22 02:49:05',
    '2025-09-30 05:56:34',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'b7b5adb5-5535-4f49-affb-430b25d3c8e1',
    'paul.gachau@turnkeyafrica.com',
    '$2a$10$pUZ9OXlQoWaCZ01cgv7jeuWnur2wAlUIC0hug5kVV4ogzymMP0UTK',
    'Paul Gachau',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    '2025-10-31 06:51:53',
    '2025-09-07 21:48:21',
    '2025-10-31 06:51:53',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'b8aafef7-91bf-4008-9d95-04b9ba78c8c1',
    'godwin.kipkemboi@turnkeyafrica.com',
    '$2a$10$Kp2LyFph2IHmFb5lWLTRoeZ4H8sszE53BymRxww7i.ljVvgck1tg.',
    'Godwin Kipkemboi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:31',
    '2025-09-07 21:47:31',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'be201788-8e22-4e63-ac95-c3816d726a2c',
    'sarah.akinyi@turnkeyafrica.com',
    '$2a$10$rQASHrsHTy.oCalKvcdnO.wcZr83SHQs.9pgRac3M/dtSUqmAgH2i',
    'Sarah Akinyii',
    'user',
    '6901b725-fd67-4d9f-9c03-9b3cee064e84',
    '+254-700-000-004',
    'Operations Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-31 22:24:17',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'bed71e31-5888-4626-bdd0-cd367f697285',
    'jeff.wachania@turnkeyafrica.com',
    '$2a$10$eiANvSs2Qq4iVC/PhNf5uOv.MbS5BRP9aX50qfHjlCZa07cRv4iwy',
    'Jeff Wachania',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:08',
    '2025-09-07 21:48:08',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'c014ad5d-0e00-4435-b70e-65ad432812a8',
    'john.ndumba@caavagroup.com',
    '$2a$10$fTCQOwBPakUXVNARxuNyAuEOi8.0YqwC2sol03gbuCRqfDS4pb5gy',
    'John Ndumba',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:10',
    '2025-09-07 21:48:10',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'c0270938-9b32-4313-b8b2-189773428310',
    'shiyonga@turnkeyafrica.com',
    '$2a$10$01Y/VGcziyv.xByM5yjFO.eh/5oEcj4sivTaAWPtzPYsXQwk/RneG',
    'Solomon Shiyonga',
    'user',
    'd5d42144-030d-4b3c-a587-ada3d7332497',
    NULL,
    'Engineering Manager',
    1,
    1,
    NULL,
    '2025-09-07 21:48:29',
    '2025-09-23 03:12:01',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'c1996462-7200-4ba2-bb2b-cb834522ecf2',
    'sostine.waliaula@turnkeyafrica.com',
    '$2a$10$nbGKlk8fnPWZLmwBeIQhS.BnLs032idfv6xmCJWSCuSu5PkizXe0q',
    'Sostine Waliaula',
    'admin',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    '',
    'CTO',
    1,
    1,
    '2025-10-28 04:49:47',
    '2025-08-28 01:33:31',
    '2025-11-03 23:01:12',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    17
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'c39691a6-a4bf-4943-badc-bc5404bf4474',
    'victor.mutisya@turnkeyafrica.com',
    '$2a$10$KniyMXV6X48APnXqtCNrXeDNL06Dn91VLqDS0wH0FrZVg1ZhhqW6K',
    'Victor Mutisya',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:33',
    '2025-09-07 21:48:33',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'c3a115e4-68f5-406e-8829-bc1cc2873b27',
    'washington.apoo@turnkeyafrica.com',
    '$2a$10$qkPMK14w2PDEt9EyvPsYduyXMGvRMlDCyny00UCPNTcUnl.rIwOUe',
    'Washington Apoo',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:32',
    '2025-09-07 21:47:32',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'c60e402b-b84d-4659-ad69-a52136fa27b7',
    'martin.ndungu@turnkeyafrica.com',
    '$2a$10$q4WaezTgFD0lRNxvhM3ikeDeUtYp2QTGY.DLfrljYx/XhJIxrZJAi',
    'Martin ndung\'u',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:15',
    '2025-09-07 21:48:15',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'c9fa7b0e-cfda-47a5-8bd7-8de6cca09bcc',
    'milkah.macharia@turnkeyafrica.com',
    '$2a$10$vmApmKGtLXLn7N4wfFuPoeJorZ5g/ealSjKPpVuBMFaQZu3slmUNe',
    'Milkah Macharia',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:18',
    '2025-09-07 21:48:18',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'cb5cc465-a4ed-11f0-a26e-08f1ea8e398e',
    'nicholas.kiplimo@turnkeyafrica.com',
    '$2a$10$IZqyM2eu9POB4CIyvXEVsuknab8yWi2CM1wyqRofNlj9WN5VW27Oe',
    'Nicholas Kiplimo',
    'manager',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0791980616',
    'Software Engineer',
    1,
    1,
    '2025-10-31 00:01:41',
    '2025-10-09 01:56:06',
    '2025-10-31 00:01:41',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'cb7be80a-bf44-4de7-a00c-a29c43b08e47',
    'sharon.nderi@caavagroup.com',
    '$2a$10$onO3W1d1MDGQLBXyyto/cedj3BRizfqT.OpeV1Y6x9kneJ4/7YOAG',
    'Sharon Nderi',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:28',
    '2025-09-07 21:48:28',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'd1bbaf2c-b2ea-4403-8d44-a22154403132',
    'robert.kiprop@turnkeyafrica.com',
    '$2a$10$H6v038NNSdHS2snUchPGgOtnHRtGpqal.HIKBUcy89WRO0uVp7mva',
    'Robert Kiprop',
    'manager',
    NULL,
    '+254-700-000-007',
    'R&D Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:12',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'd2d6239b-a520-11f0-a26e-08f1ea8e398e',
    'ogunjimi.tunde@turnkeyafrica.com',
    '$2a$10$SXVZkgRgfQztx7EP58yHb.kK7NRekVcxnH.d7OYnq0TRpdgCgz2LK',
    'Tunde Ogunjimi',
    'user',
    'ebccace8-a51f-11f0-a26e-08f1ea8e398e',
    NULL,
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 08:01:23',
    '2025-10-09 08:01:23',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'd7c07b9d-4b45-485d-9cb0-5c48958ee7a7',
    'doreen.auma@caavagroup.com',
    '$2a$10$v/QDqI9IikyORzRW1li7E.ZR9i5ZjNZzqilKm1E.PsrQyXnyKrR8K',
    'Doreen Auma',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:48',
    '2025-09-07 21:47:48',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'd8888ad5-6736-44f4-ae27-70714341f083',
    'dorice.amolo@turnkeyafrica.com',
    '$2a$10$NywmM.oaN/jbf1awMMLMCernyCeJZaMjBrfcW6/IzMSkqJjhaWXEO',
    'Dorice Amolo',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:49',
    '2025-09-07 21:47:49',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'da93ab12-850e-46d3-8bc4-eee96139fd30',
    'mercy.chemutai@caavagroup.com',
    '$2a$10$KSKXSqpsTYWdU9tPIFVFue14ycGgF4aXV07Zl7YsadQBMpsLPY/pq',
    'Mercy Chemutai',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:17',
    '2025-09-07 21:48:17',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'dbfec091-60bc-4c9a-9064-5e02d210c45e',
    'eric.wathome@agencify.insure',
    '$2a$10$iOvcwdmQ1mfN5PmfrKUe0OjoZa0ekUBcbiQtKU1ULwuDaSA55282u',
    'Eric Wathome',
    'manager',
    'c6b07ab2-b175-4a74-a3f9-2afeac9b52b7',
    NULL,
    'Technical Lead',
    1,
    1,
    NULL,
    '2025-09-21 23:48:00',
    '2025-10-29 00:36:26',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'dd2174a3-49b5-4eae-bba5-904322d93b26',
    'esther.nalotwesha@turnkeyafrica.com',
    '$2a$10$okVVTmsRdJ.0YyfSYPtaiedveWYWtUv7tnZ6KSuzbrJ602igxSe.q',
    'ESTHER NALOTWESHA',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:56',
    '2025-09-07 21:47:56',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'df85ef77-a1de-40a6-8eff-3c642c33f879',
    'walter.ndege@caavagroup.com',
    '$2a$10$fXxJ6IEpNP/CI8KErRIZ4.5zLxa9X7lZYuzTdEsuXOlMQtbQ3eNRi',
    'Walter Ndege',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:33',
    '2025-09-07 21:48:33',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e0392d52-a522-11f0-a26e-08f1ea8e398e',
    'dancan.kavagi@turnkeyafrica.com',
    '$2a$10$yg7VEtp2Mt395qz906tDIeb.bWfNM41xf536DVootPt.WCvxcx3ZC',
    'Dancan Kavagi',
    'user',
    '769ab972-a522-11f0-a26e-08f1ea8e398e',
    NULL,
    'Software Engineer',
    1,
    1,
    NULL,
    '2025-10-09 08:16:04',
    '2025-10-09 08:16:04',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e066a45a-fb42-43e2-bc28-2b928b31f470',
    'brayan.mbagara@turnkeyafrica.com',
    '$2a$10$ar.NaxCKn2LQ3ZPR37qeIuArpqpK/6fO5ThiCv8gImIveYi0q/NKW',
    'Brayan Mbagara',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:38',
    '2025-09-07 21:47:38',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e0b59757-ad10-4386-a151-1991ed7bad53',
    'test2@turnkeyafrica.com',
    '$2a$10$8R0CtNF1uAIpFRRSK57Hm.26dopTs6A3GVgJ.iNKv6shSooVhu0ba',
    'test2',
    'user',
    '75c916f7-0ff5-460b-8055-7eeba640424d',
    NULL,
    'Customer Management',
    1,
    1,
    NULL,
    '2025-11-04 00:18:35',
    '2025-11-04 00:18:35',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e541d038-a51e-11f0-a26e-08f1ea8e398e',
    'paul.okweso@turnkeyafrica.com',
    '$2a$10$8l8IKy/USQUMDdFQb3/6aOaL.UVqRoVdxSsg5M2sVucYkuZ5JVL6W',
    'Paul Okweso',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0717836655',
    'Intern-Engineering',
    1,
    1,
    NULL,
    '2025-10-09 07:47:35',
    '2025-10-09 07:47:35',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e5ee0483-a51d-11f0-a26e-08f1ea8e398e',
    'emmanuel.mutua@turnkeyafrica.com',
    '$2a$10$iprF/JfzD1jN2mHaZxoyo.bGkokj6xgTFRh2HrnKZSvlz3axwiUUq',
    'Emmanuel Mutua',
    'user',
    '32904d1e-a4ed-11f0-a26e-08f1ea8e398e',
    '0743411856',
    'Software Engineer',
    1,
    1,
    '2025-10-09 09:06:48',
    '2025-10-09 07:40:26',
    '2025-10-09 09:06:48',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e5f75e57-fe01-41cc-ae83-33ab0aab3811',
    'daniel.matheri@turnkeyafrica.com',
    '$2a$10$pJ4BrVLZnSW1fR5wVNRn3O8QYGIpWapIh.f3WCH19bFzmDp.iEg2y',
    'Daniel Matheri',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:47',
    '2025-09-07 21:47:47',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e6630cd5-d2cf-4cce-b979-109aa0c2184c',
    'john.odhiambo@turnkeyafrica.com',
    '$2a$10$FZflfWiXxenlDs7gRYXGHubgfnHB.Lbjthlo1jW5VI7h7.sYK22WK',
    'John Odhiambo',
    'manager',
    NULL,
    '+254-700-000-001',
    'IT Manager',
    1,
    1,
    NULL,
    '2025-08-10 01:04:16',
    '2025-08-12 03:33:07',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e71f72ea-117c-42a8-9fce-74667dd5a170',
    'shikoli@turnkeyafrica.com',
    '$2a$10$hTNHk92SuMaNTvZQMRAijOBH5qf5rCyET3EY3vzuAp6V7V6LBIYkC',
    'Shikoli Makatiani',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:28',
    '2025-09-07 21:48:28',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'e983b624-4b37-4984-a812-6ea0a1b0a127',
    'faith.kariuki@turnkeyafrica.com',
    '$2a$10$qTIUAw1kHhcC73ycjIhM.OqtBXHVIJqBG5pkJE8NbEAmrAlTAIX3K',
    'Faith Kariuki',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:57',
    '2025-09-07 21:47:57',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'efbb9ac6-2c69-4935-a5ef-68d683119bcf',
    'emmanuel.muema@turnkeyafrica.com',
    '$2a$10$sVYsymwPjIEW3Eeuq7hrfenccYk7ldUohLVqzGqGmLylC6DY9vkQu',
    'Emmanuel Muema',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:55',
    '2025-09-07 21:47:55',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'efff8c10-9259-4696-9a99-913317066cec',
    'elishebar.wanjira@turnkeyafrica.com',
    '$2a$10$pZv3rO2fBeUfMdG5ZjxgbOpibSShmQUwv4GsnZqfijzsRMfZedH8.',
    'elishebar wanjira',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:53',
    '2025-09-07 21:47:53',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f06ad83b-7880-486c-abcc-72ba9206baa3',
    'it@turnkeyafrica.com',
    '$2a$10$ht8jfekAL9Q1vTGmur7DUeseJAqgwxC8cWAIZksiu5Jx9BBEGJwLy',
    'Infra Team - IT',
    'user',
    '3cc10cde-e50e-41e2-8b78-53917e7b5d95',
    '',
    'System Engineer',
    1,
    1,
    NULL,
    '2025-10-27 02:18:54',
    '2025-11-03 23:00:21',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f0fe169d-7c74-4709-b8b3-de27dd9d4364',
    'grace.fiona@turnkeyafrica.com',
    '$2a$10$Oc1SxUXpP6XFRBLvowOyt.V.RJIMfTgP.DtU1BC9KQ40dQGa4AOOq',
    'Grace Fiona',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:00',
    '2025-09-07 21:48:00',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f46e546c-0767-4bd7-a3c7-064a20322c9f',
    'caroline.gatwiri@caavagroup.com',
    '$2a$10$jL17JnRluo8vPGo56u8dCeBT3qQJSqRh1ijO9kwQE17TAMn1ZzGta',
    'Caroline Gatwiri',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:41',
    '2025-09-07 21:47:41',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f73ffdc6-a523-11f0-a26e-08f1ea8e398e',
    'nicholas.mariga@turnkeyafrica.com',
    '$2a$10$vw2m6YAKK5ltcLNLb345f./f4knYMptqay0hb9gzPGl6dj/Sv5y/C',
    'Nicholas Mariga',
    'user',
    '05156680-9d4d-4706-bb9b-2de3753d2648',
    '',
    'System Engineer',
    1,
    1,
    '2025-10-26 23:55:42',
    '2025-10-09 08:23:53',
    '2025-10-26 23:57:44',
    1,
    1,
    '2025-10-26 23:57:44',
    '2025-10-26 23:57:44',
    0,
    NULL,
    1
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f7ee085f-f79c-437a-bd73-3abbecd9e214',
    'austine.were@turnkeyafrica.com',
    '$2a$10$7zyR1kYgrzw/MRjfPRLdm.oPSJ/tjZjcr27342CeHsqKNLjEXpXpW',
    'Austine Were',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:36',
    '2025-09-07 21:47:36',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f8527332-a873-4102-9ff4-c17505eb4e58',
    'peter.kiguru@agencify.insure',
    '$2a$10$ZCEvzVQOaGkTnjE8Xbwl7OMmlt7Fnf2.5GpqPJvr02/PAVtX4IT7e',
    'Peter Kiguru',
    'manager',
    '96735c8a-4570-45b0-bd87-5bd4bf201702',
    '0715382787',
    'Support Intern',
    1,
    1,
    NULL,
    '2025-11-03 03:53:15',
    '2025-11-03 03:53:35',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f85fc32f-08aa-4689-aa5a-37823ba4dcee',
    'amos.mandela@turnkeyafrica.com',
    '$2a$10$bOGU.MX51V4u57Jezwr/Pupo/zx1X.YWMYEugkAhn3XZieBMNMdvG',
    'Amos Mandela',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:34',
    '2025-09-07 21:47:34',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'f9914508-7fa9-4a09-a6aa-3d5aa83850fe',
    'emmanuel.wangila@turnkeyafrica.com',
    '$2a$10$gCdSLOncqxAZQw3sLief0OtBt3dEjDrMfg3ELFEHwDjQ8YXfWXWkm',
    'Emmanuel Wangila',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:54',
    '2025-09-07 21:47:54',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'fc39ad2e-9bcf-49bd-b3c3-500fc1bcbc6f',
    'reagan.ochieng@turnkeyafrica.com',
    '$2a$10$0uj/AE3Z4mJB8gh2P/N2D.puX1.EbyB0eJ7xDqO.tlsRz0IbliuXO',
    'Reagan Ochieng',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:23',
    '2025-09-07 21:48:23',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'fc4133bf-fd07-4b52-94ae-9c5e47e5b75e',
    'japheth.namukuru@turnkeyafrica.com',
    '$2a$10$sZNvsVF3yz4Ztrjh/nzO7evgKfxaxhdwLOz8TJKAT0w8rdMf8eNOi',
    'Japheth Namukuru',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:48:07',
    '2025-09-07 21:48:07',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password_hash`,
    `name`,
    `role`,
    `department_id`,
    `phone`,
    `position`,
    `is_active`,
    `email_notifications`,
    `last_login`,
    `created_at`,
    `updated_at`,
    `in_app_notifications`,
    `mfa_enabled`,
    `mfa_enrolled_at`,
    `last_mfa_verification`,
    `mfa_policy_required`,
    `mfa_grace_period_end`,
    `mfa_policy_violations`
  )
VALUES
  (
    'fe150343-7687-42ff-ad0d-e80ebf1c548f',
    'belinda.otieno@turnkeyafrica.com',
    '$2a$10$gz5B51vo.D80WC57HF7WKuI4R2eeZV45zNE7.hv.SXv3uTYxcrF6a',
    'Belinda Otieno',
    'user',
    NULL,
    NULL,
    NULL,
    1,
    1,
    NULL,
    '2025-09-07 21:47:38',
    '2025-09-07 21:47:38',
    1,
    0,
    NULL,
    NULL,
    0,
    NULL,
    0
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
